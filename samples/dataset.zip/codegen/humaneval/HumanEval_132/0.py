
def is_nested(string):
    '''
    Create a function that takes a string as input which contains only square brackets.
    The function should return True if and only if there is a valid subsequence of brackets 
    where at least one bracket in the subsequence is nested.

    is_nested('[[]]') ➞ True
    is_nested('[]]]]]]][[[[[]') ➞ False
    is_nested('[][]') ➞ False
    is_nested('[]') ➞ False
    is_nested('[[][]]') ➞ True
    is_nested('[[]][[') ➞ True
    '''
    
    # if string is empty, return False
    if not string:
        return False
    
    # if string is not empty, check if there is a valid subsequence of brackets
    # if there is, return True
    # if there is not, return False
    
    # create a stack to store the brackets
    stack = []
    
    # iterate through the string
    for char in string:
        
        # if the character is a left bracket, push it to the stack
        if char == '[':
            stack.append(char)
        
        # if the character is a right bracket, pop the last element from the stack
        # if the last element is a left bracket, return True
        # if the last element is not a left bracket, return False
        elif char == ']':
            if stack:
                stack.pop()
            else:
                return False
    
    # if the stack is empty, return True
    # if the stack is not empty, return False
    if not stack:
        return True
    else:
        return False
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    