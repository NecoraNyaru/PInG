"""
Write a python function to find the average of cubes of first n natural numbers.
assert find_Average_Of_Cube(2) == 4.5
"""

def find_Average_Of_Cube(n):
    return (n*(n+1)*(n+2))/6

print(find_Average_Of_Cube(2))

"""
Write a python function to find the average of cubes of first n natural numbers.
assert find_Average_Of_Cube(2) == 4.5
"""

def find_Average_Of_Cube(n):
    return (n*(n+1)*(n+2))/6

print(find_Average_Of_Cube(2))

"""
Write a python function to find the average of cubes of first n natural numbers.
assert find_Average_Of_Cube(2) == 4.5
"""

def find_Average_Of_Cube(n):
    return (n*(n+1)*(n+2))/6

print(find_Average_Of_Cube(2))

"""
Write a python function to find the average of cubes of first n natural numbers.
assert find_Average_Of_Cube(2) == 4.5
"""

def find_Average_Of_Cube(n):
    return (n*(n+1)*(n+2))/6

print(find_Average_Of_Cube(2))

"""
Write a python function to find the average of cubes of first n natural numbers.
assert find_Average_Of_Cube(2) == 4.5
"""

def find_Average_Of_Cube(n):
    return (n*(n+1)*(n+2))/6

print(find_Average_Of_Cube(2))

"""
Write a python function to find the average of cubes of first n natural numbers.
assert find_Average_Of_Cube(2) == 4.5
"""

def find_Average_Of_Cube(n):
    return (n*(n+1)*(n+2))/6

print(find_Average_Of_Cube(2))

"""
Write a python function to find the average of cubes of first n natural numbers.
assert find_Average_Of_Cube(2) == 4.5
"""

def find_Average_Of_Cube(n):
    