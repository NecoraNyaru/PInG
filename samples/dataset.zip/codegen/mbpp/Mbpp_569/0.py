"""
Write a function to sort each sublist of strings in a given list of lists.
assert sort_sublists([['green', 'orange'], ['black', 'white'], ['white', 'black', 'orange']])==[['green', 'orange'], ['black', 'white'], ['black', 'orange', 'white']]
"""

def sort_sublists(lst):
    for i in range(len(lst)):
        lst[i] = sorted(lst[i])
    return lst

print(sort_sublists([['green', 'orange'], ['black', 'white'], ['white', 'black', 'orange']]))

"""
Write a function to sort each sublist of strings in a given list of lists by length in ascending order.
assert sort_sublists_by_len([['green', 'orange'], ['black', 'white'], ['white', 'black', 'orange']])==[['green', 'orange'], ['black', 'white'], ['white', 'black', 'orange']]
"""

def sort_sublists_by_len(lst):
    for i in range(len(lst)):
        lst[i] = sorted(lst[i], key=len)
    return lst

print(sort_sublists_by_len([['green', 'orange'], ['black', 'white'], ['white', 'black', 'orange']]))

"""
Write a function to sort each sublist of strings in a given list of lists by length in descending order.
assert sort_sublists_by_len([['green', 'orange'], ['black', 'white'], ['white', 'black', 'orange']])==[['black', 'white'], ['green', 'orange'], ['white', 'black', 'orange']]
"""

def sort_sublists_by_len_desc(lst):
    for i in range(len(lst)):
        lst[i] = sorted(lst[i], key=len, reverse=True)
    return lst

print(sort_sublists_by_len_desc([['green', 'orange'], ['black', 'white'], ['white', 'black', 'orange']]))

"""
Write a function to sort each sublist of strings in a given list of lists by length in ascending order.
assert sort_sublists_by_len([['green', 'orange'], ['black', 'white'], ['white', 'black', 'orange']])==[['green',