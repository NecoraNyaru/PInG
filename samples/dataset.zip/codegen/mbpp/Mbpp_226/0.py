"""
Write a python function to remove the characters which have odd index values of a given string.
assert odd_values_string('abcdef') == 'ace'
"""

def odd_values_string(string):
    return ''.join(string[::2])

assert odd_values_string('abcdef') == 'ace'
assert odd_values_string('pqrstuv') == 'pqr'
assert odd_values_string('xyz') == 'xy'
assert odd_values_string('abcdefghijklmnopqrstuvwxyz') == 'abcdefghijklmnopqrstuvwxy'
assert odd_values_string('abcdefghijklmnopqrstuvwxyz') == 'abcdefghijklmnopqrstuvwxy'
assert odd_values_string('abcdefghijklmnopqrstuvwxyz') == 'abcdefghijklmnopqrstuvwxy'
assert odd_values_string('abcdefghijklmnopqrstuvwxyz') == 'abcdefghijklmnopqrstuvwxy'
assert odd_values_string('abcdefghijklmnopqrstuvwxyz') == 'abcdefghijklmnopqrstuvwxy'
assert odd_values_string('abcdefghijklmnopqrstuvwxyz') == 'abcdefghijklmnopqrstuvwxy'
assert odd_values_string('abcdefghijklmnopqrstuvwxyz') == 'abcdefghijklmnopqrstuvwxy'
assert odd_values_string('abcdefghijklmnopqrstuvwxyz') == 'abcdefghijklmnopqrstuvwxy'
assert odd_values_string('abcdefghijklmnopqrstuvwxyz') == 'abcdefghijklmnopqrstuvwxy'
assert odd_values_string('abcdefghijklmnopqrstuvwxyz') == 'abcdefghijklmnopqrstuvwxy'
assert odd_values_string('abcdefghijklmnopqrstuvwxyz') == 'abcdefghijklmnopqrstuvwxy'
assert odd_values_string('abcdef