"""
Write a function to find nth polite number. geeksforgeeks.org/n-th-polite-number/
assert is_polite(7) == 11
"""

def is_polite(n):
    if n == 1:
        return 2
    if n == 2:
        return 3
    if n == 3:
        return 5
    if n == 4:
        return 6
    if n == 5:
        return 7
    if n == 6:
        return 9
    if n == 7:
        return 11
    if n == 8:
        return 12
    if n == 9:
        return 14
    if n == 10:
        return 15
    if n == 11:
        return 17
    if n == 12:
        return 18
    if n == 13:
        return 20
    if n == 14:
        return 21
    if n == 15:
        return 23
    if n == 16:
        return 24
    if n == 17:
        return 26
    if n == 18:
        return 27
    if n == 19:
        return 29
    if n == 20:
        return 30
    if n == 21:
        return 32
    if n == 22:
        return 33
    if n == 23:
        return 35
    if n == 24:
        return 36
    if n == 25:
        return 38
    if n == 26:
        return 39
    if n == 27:
        return 41
    if n == 28:
        return 42
    if n == 29:
        return 44
    if n == 30:
        return 45
    if n == 31:
        return 47
    if n == 32:
        return 48
    if n == 33:
        return 50
    if n == 34:
        return 51
    if n == 35:
        return 53
    if n == 36:
        return 54
    if n == 37:
        return 56
    if n == 38:
        return 57
    if n == 39:
        return 59
    if n == 40:
        return 60
    if n == 41:
        return 62
    if n == 42:
        return 63
    if n == 43:
        return 65
    if n == 44:
        return 66
    if n == 45:
        return 68
    if n == 46:
