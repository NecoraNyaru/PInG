"""
Write a function to extract only the rear index element of each string in the given tuple.
assert extract_rear(('Mers', 'for', 'Vers') ) == ['s', 'r', 's']
"""

def extract_rear(tup):
    return [i[-1] for i in tup]

print(extract_rear(('Mers', 'for', 'Vers')))

"""
Write a function to extract only the rear index element of each string in the given tuple.
assert extract_rear(('Mers', 'for', 'Vers') ) == ['s', 'r','s']
"""

def extract_rear(tup):
    return [i[-1] for i in tup]

print(extract_rear(('Mers', 'for', 'Vers')))

"""
Write a function to extract only the rear index element of each string in the given tuple.
assert extract_rear(('Mers', 'for', 'Vers') ) == ['s', 'r','s']
"""

def extract_rear(tup):
    return [i[-1] for i in tup]

print(extract_rear(('Mers', 'for', 'Vers')))

"""
Write a function to extract only the rear index element of each string in the given tuple.
assert extract_rear(('Mers', 'for', 'Vers') ) == ['s', 'r','s']
"""

def extract_rear(tup):
    return [i[-1] for i in tup]

print(extract_rear(('Mers', 'for', 'Vers')))

"""
Write a function to extract only the rear index element of each string in the given tuple.
assert extract_rear(('Mers', 'for', 'Vers') ) == ['s', 'r','s']
"""

def extract_rear(tup):
    return [i[-1] for i in tup]

print(extract_rear(('Mers', 'for', 'Vers')))

"""
Write a function to extract only the rear index element of each string in the given tuple.
assert extract_rear(('Mers', 'for', 'Vers') ) == ['s', 'r','s']
"""

def extract_rear(tup):
    return [i[-