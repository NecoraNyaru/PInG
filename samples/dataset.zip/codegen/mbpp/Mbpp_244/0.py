"""
Write a python function to find the next perfect square greater than a given number.
assert next_Perfect_Square(35) == 36
"""

def next_Perfect_Square(n):
    """
    >>> next_Perfect_Square(35)
    36
    """
    if n == 1:
        return 2
    else:
        return int(n**0.5) + 1

"""
Write a python function to find the next perfect square greater than a given number.
assert next_Perfect_Square(35) == 36
"""

def next_Perfect_Square(n):
    """
    >>> next_Perfect_Square(35)
    36
    """
    if n == 1:
        return 2
    else:
        return int(n**0.5) + 1

"""
Write a python function to find the next perfect square greater than a given number.
assert next_Perfect_Square(35) == 36
"""

def next_Perfect_Square(n):
    """
    >>> next_Perfect_Square(35)
    36
    """
    if n == 1:
        return 2
    else:
        return int(n**0.5) + 1

"""
Write a python function to find the next perfect square greater than a given number.
assert next_Perfect_Square(35) == 36
"""

def next_Perfect_Square(n):
    """
    >>> next_Perfect_Square(35)
    36
    """
    if n == 1:
        return 2
    else:
        return int(n**0.5) + 1

"""
Write a python function to find the next perfect square greater than a given number.
assert next_Perfect_Square(35) == 36
"""

def next_Perfect_Square(n):
    """
    >>> next_Perfect_Square(35)
    36
    """
    if n == 1:
        return 2
    else:
        return int(n**0.5) + 1

"""
Write a python function to find the next perfect square greater than a given number.
assert next_Perfect_Square(35) == 36
"""

def next_Perfect_Square(n):
    """
    >>> next_Perfect_Square(35)
    36
    """
    if n == 1:
        return 2
    else:
        