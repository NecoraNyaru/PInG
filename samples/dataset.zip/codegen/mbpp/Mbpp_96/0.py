"""
Write a python function to find the number of divisors of a given integer.
assert divisor(15) == 4
"""

def divisor(n):
    divisors = 1
    for i in range(2, n):
        if n % i == 0:
            divisors += 1
    return divisors

"""
Write a python function to find the number of divisors of a given integer.
assert divisor(15) == 4
"""

def divisor(n):
    divisors = 1
    for i in range(2, n):
        if n % i == 0:
            divisors += 1
    return divisors

"""
Write a python function to find the number of divisors of a given integer.
assert divisor(15) == 4
"""

def divisor(n):
    divisors = 1
    for i in range(2, n):
        if n % i == 0:
            divisors += 1
    return divisors

"""
Write a python function to find the number of divisors of a given integer.
assert divisor(15) == 4
"""

def divisor(n):
    divisors = 1
    for i in range(2, n):
        if n % i == 0:
            divisors += 1
    return divisors

"""
Write a python function to find the number of divisors of a given integer.
assert divisor(15) == 4
"""

def divisor(n):
    divisors = 1
    for i in range(2, n):
        if n % i == 0:
            divisors += 1
    return divisors

"""
Write a python function to find the number of divisors of a given integer.
assert divisor(15) == 4
"""

def divisor(n):
    divisors = 1
    for i in range(2, n):
        if n % i == 0:
            divisors += 1
    return divisors

"""
Write a python function to find the number of divisors of a given integer.
assert divisor(15) == 4
"""

def divisor(n):
    divisors = 1
    for i in