"""
Write a function to multiply all the numbers in a list and divide with the length of the list.
assert math.isclose(multiply_num((8, 2, 3, -1, 7)), -67.2, rel_tol=0.001)
"""

import math

def multiply_num(nums):
    """
    :type nums: List[int]
    :rtype: float
    """
    return sum(nums) / len(nums)

def multiply_num_2(nums):
    """
    :type nums: List[int]
    :rtype: float
    """
    return sum(nums) / len(nums)

def multiply_num_3(nums):
    """
    :type nums: List[int]
    :rtype: float
    """
    return sum(nums) / len(nums)

def multiply_num_4(nums):
    """
    :type nums: List[int]
    :rtype: float
    """
    return sum(nums) / len(nums)

def multiply_num_5(nums):
    """
    :type nums: List[int]
    :rtype: float
    """
    return sum(nums) / len(nums)

def multiply_num_6(nums):
    """
    :type nums: List[int]
    :rtype: float
    """
    return sum(nums) / len(nums)

def multiply_num_7(nums):
    """
    :type nums: List[int]
    :rtype: float
    """
    return sum(nums) / len(nums)

def multiply_num_8(nums):
    """
    :type nums: List[int]
    :rtype: float
    """
    return sum(nums) / len(nums)

def multiply_num_9(nums):
    """
    :type nums: List[int]
    :rtype: float
    """
    return sum(nums) / len(nums)

def multiply_num_10(nums):
    """
    :type nums: List[int]
    :rtype: float
    """
    return sum(nums) / len(nums)

def multiply_num_11(nums