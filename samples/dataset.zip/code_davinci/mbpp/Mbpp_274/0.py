Here's the Python function that takes in a positive integer n and finds the sum of even index binomial coefficients:

```python
def even_binomial_Coeff_Sum(n):
    sum = 0
    for i in range(0, n+1):
        sum += binomial_Coeff(n, i)
    return sum

def binomial_Coeff(n, k):
    if k == 0 or k == n:
        return 1
    else:
        return binomial_Coeff(n-1, k-1) + binomial_Coeff(n-1, k)
```

Explanation:

The function `even_binomial_Coeff_Sum` takes in a positive integer `n` and initializes a variable `sum` to 0. It then iterates through the range of 0 to `n+1` using a for loop and adds the result of the binomial coefficient function `binomial_Coeff` to the `sum` variable for each even index `i`. The `binomial_Coeff` function is a recursive function that calculates the binomial coefficient using the formula `(n choose k) = n! / (k! * (n-k)!)` where `!` represents factorial. The function returns 1 if `k` is 0 or `n` since there are no even index binomial coefficients for those values. Otherwise, it calculates the binomial coefficient for `n-1` and `k-1` and adds it to the result of the binomial coefficient for `n-1` and `k`. This continues until the base case of `k=0` or `k=n` is reached. Finally, the function returns the sum of all the binomial coefficients calculated. 