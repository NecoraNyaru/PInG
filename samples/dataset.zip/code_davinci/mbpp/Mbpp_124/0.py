Here's a Python function that takes a complex number as input and returns its angle in radians:

```python
import math

def angle_complex(z):
    return math.atan2(z.imag, z.real)
```

This function uses the `math.atan2()` function to calculate the angle of the complex number `z` in radians. The `math.atan2()` function takes two arguments: the `y` coordinate and the `x` coordinate of the complex number, and returns the angle in radians. Since the `y` coordinate is `0` for the given input, we only need to pass in the `x` coordinate, which is `1j`. The `math.atan2()` function returns the angle in the range `-pi <= angle <= pi`, so we don't need to worry about the quadrant of the number. We can use `math.pi` to convert the angle to radians if needed.

To test the function, we can use the `math.isclose()` function to check if the result is close to the expected value:

```python
assert math.isclose(angle_complex(0,1j), 1.5707963267948966, rel_tol=0.001)
```

This asserts that the angle of `0 + 1j` is close to `pi/2` (1.5707963267948966 radians) within a relative tolerance of 0.001. If the function works correctly, the assertion should pass. 