Here's the Python code to find perfect squares between two given numbers:

```python
def perfect_squares(start, end):
    """
    This function takes two numbers as input and returns a list of perfect squares between them.
    """
    perfect_squares_list = []
    for i in range(start, end+1):
        if i**0.5 == int(i**0.5):
            perfect_squares_list.append(i**2)
    return perfect_squares_list
```

Explanation:

We first initialize an empty list called `perfect_squares_list`. We then loop through all the numbers between `start` and `end` (inclusive) using a `for` loop. For each number `i`, we check if its square root is an integer using the `int()` function. If it is, we append its square to the list. Finally, we return the list of perfect squares. 