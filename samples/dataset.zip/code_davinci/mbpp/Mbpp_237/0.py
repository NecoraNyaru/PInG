Here's the Python script that solves the problem:

```python
def check_occurences(lst):
    count_dict = {}
    for tup in lst:
        if tup in count_dict:
            count_dict[tup] += 1
        else:
            count_dict[tup] = 1
    return count_dict
```

This function takes in a list of tuples `lst` and initializes an empty dictionary `count_dict`. It then iterates through each tuple in the list and checks if it already exists in the dictionary. If it does, it increments the count of that tuple by 1. If it doesn't, it adds the tuple to the dictionary with a count of 1. Finally, it returns the dictionary. 