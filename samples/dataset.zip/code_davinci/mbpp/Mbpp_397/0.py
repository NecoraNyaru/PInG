Here's the Python code to find the median of three numbers:

```python
def median_numbers(num1, num2, num3):
    """
    This function takes three numbers as input and returns their median value.
    """
    numbers = [num1, num2, num3]
    numbers.sort()
    median = numbers[1]
    return median

# Test the function
print(median_numbers(25, 55, 65)) # Output: 55.0
```

Explanation:

We first define a function `median_numbers` that takes three numbers as input and returns their median value. We create a list `numbers` containing the three numbers and sort it in ascending order. The median is the middle element of the list, which is at index 1 since Python uses 0-based indexing. We then return the median value. Finally, we test the function by calling it with the values 25, 55, and 65 and print the output, which should be 55.0. 