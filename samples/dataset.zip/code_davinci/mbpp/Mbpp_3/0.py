Here's a Python function that identifies non-prime numbers:

```python
def is_not_prime(n):
    if n < 2:
        return True
    for i in range(2, int(n**0.5)+1):
        if n % i == 0:
            return True
    return False
```

This function takes an integer `n` as input and returns `True` if `n` is not a prime number, and `False` otherwise. It first checks if `n` is less than 2, in which case it is not a prime number. Then, it iterates over all numbers from 2 to the square root of `n` and checks if `n` is divisible by any of them. If it is, it returns `True`, indicating that `n` is not a prime number. If it is not divisible by any of them, it returns `False`, indicating that `n` is a prime number. 