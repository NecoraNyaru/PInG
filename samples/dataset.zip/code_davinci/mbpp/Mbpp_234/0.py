Here's the Python code to find the volume of a cube given its side length:

```python
def volume_cube(side):
    return side ** 3
```

This function takes in a single argument `side`, which is the length of one side of the cube, and returns the volume of the cube, which is calculated by raising the side length to the power of 3. We can test this function with the given assertion:

```python
assert volume_cube(3) == 27
```

This will pass, since the volume of a cube with side length 3 is 3 cubed, which is 27. 