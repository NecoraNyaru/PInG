Here's the Python function to find the first digit of a given number:

```python
def first_digit(num):
    return int(str(num)[0])
```

This function takes a number as input and returns the first digit of the number as an integer. We convert the number to a string using the `str()` function and then return the first character of the string using indexing. The `[0]` index returns the first character of the string. 