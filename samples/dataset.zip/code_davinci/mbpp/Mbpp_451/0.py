Here's the Python script to remove all whitespaces from a given string:

```python
def remove_whitespaces(string):
    return string.replace(" ", "")
```

This function takes a string as an argument and returns a new string with all the whitespaces removed. The `replace()` method is used to replace all the whitespace characters with an empty string. The `replace()` method takes two arguments - the character to be replaced and the replacement character. In this case, we are replacing all the whitespace characters with an empty string. 