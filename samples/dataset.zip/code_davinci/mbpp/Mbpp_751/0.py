Here's the Python function to check if the given array represents a min heap or not:

```python
def check_min_heap(arr):
    n = len(arr)
    for i in range(n//2):
        if arr[i] > arr[2*i+1] or arr[i] > arr[2*i+2]:
            return False
        if 2*i+2 < n and arr[2*i+1] > arr[2*i+2]:
            return False
    return True
```

Explanation:

We start by checking if the root element is less than or equal to its children. If any of the root elements are greater than its children, then it is not a min heap. We then move to the next level of the tree and check if the left child is less than or equal to its right child. If any of the left child is greater than its right child, then it is not a min heap. We continue this process until we reach the last level of the tree. If all the elements are less than or equal to their children, then it is a min heap.

Time Complexity: O(n)

Space Complexity: O(1) 