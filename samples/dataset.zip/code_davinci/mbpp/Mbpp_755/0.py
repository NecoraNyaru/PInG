Here's a possible solution:

def second_smallest(lst):
    """
    Returns the second smallest number in a list.
    """
    # Sort the list in ascending order
    lst.sort()
    # Return the second element of the sorted list
    return lst[1]

# Test the function with the example input
print(second_smallest([1, 2, -8, -2, 0, -2])) # Output: -2 