Here's the Python function that takes a list and returns a list with the same elements, but the k'th element removed:

```python
def remove_kth_element(lst, k):
    return lst[:k] + lst[k+1:]
```

This function takes two arguments: `lst` is the list to be modified and `k` is the index of the element to be removed. It uses slicing to return a new list that excludes the element at index `k`. The first part of the slicing operation (`lst[:k]`) creates a new list with all the elements before the k'th element, and the second part (`lst[k+1:]`) creates a new list with all the elements after the k'th element. By concatenating these two lists, we get a new list that excludes the k'th element. 