Here's the Python script to multiply all the numbers in a list and divide with the length of the list:

```python
import math

def multiply_num(lst):
    product = 1
    for num in lst:
        product *= num
    return product / len(lst)

assert math.isclose(multiply_num((8, 2, 3, -1, 7), rel_tol=0.001)
```

The `math.isclose()` function is used to check if the result is close to the expected value within a relative tolerance of 0.001. The `rel_tol` parameter specifies the relative tolerance. If the result is within 0.001 of the expected value, it returns `True`. Otherwise, it returns `False`. 