Here's a Python function that finds the directrix of a parabola given the focus and vertex of the parabola:

```python
def parabola_directrix(focus, vertex_x, vertex_y):
    """
    This function takes in the focus and vertex of a parabola and returns the directrix of the parabola.
    """
    directrix = vertex_y - 2 * focus
    return directrix
```

To test the function, we can call it with the given input:

```python
assert parabola_directrix(5,3,2) == -198
```

This function assumes that the vertex of the parabola is at (0,0) and the focus is at (0,0). If the vertex is at a different location, we can adjust the function accordingly. 