Here's the Python function to find tuples which have all elements divisible by k from the given list of tuples:

```python
def find_tuples(lst, k):
    result = []
    for tup in lst:
        if all(x % k == 0 for x in tup):
            result.append(tup)
    return result
```

This function takes a list of tuples `lst` and an integer `k` as input. It iterates through each tuple in the list and checks if all the elements in the tuple are divisible by `k` using the `all()` function. If all the elements are divisible by `k`, it appends the tuple to the `result` list. Finally, it returns the `result` list containing all the tuples that have all elements divisible by `k`.

For example, if we call `find_tuples([(6, 24, 12), (7, 9, 6), (12, 18, 21)], 6)`, it will return `[(6, 24, 12)]` since only `(6, 24, 12)` has all elements divisible by 6. 