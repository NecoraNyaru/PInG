Here's the Python function to find the sum of the fourth power of the first n odd natural numbers:

```python
def odd_num_sum(n):
    sum = 0
    for i in range(1, n+1, 2):
        sum += i**4
    return sum
```

Explanation:
- We initialize a variable `sum` to 0.
- We use a `for` loop to iterate from 1 to `n+1` with a step of 2, which means we only consider odd numbers.
- For each odd number `i`, we add its fourth power to the `sum` variable.
- Finally, we return the `sum` variable.

Example:
```python
>>> odd_num_sum(2)
82
```

The first two odd numbers are 1 and 3, and their fourth powers are 1 and 9, respectively. Therefore, the sum of their fourth powers is 10. 