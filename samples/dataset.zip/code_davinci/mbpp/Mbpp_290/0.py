Here's the Python function to find the list of maximum length in a list of lists:

```python
def max_length(lst):
    max_length = 0
    max_lst = []
    for sub_lst in lst:
        if len(sub_lst) > max_length:
            max_length = len(sub_lst)
            max_lst = sub_lst
    return max_length, max_lst
```

This function takes a list of lists as input and iterates through each sublist to find the length of the longest sublist. It then updates the maximum length and the corresponding sublist if a longer sublist is found. Finally, it returns a tuple containing the maximum length and the sublist with that length. In this case, the output would be `(3, [13, 15, 17])`. 