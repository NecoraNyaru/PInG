Here's a possible solution:

```python
def extract_values(string):
    # Split the string by comma and remove the quotation marks
    values = string.split(',')
    values = [value.strip('"') for value in values]
    return values
```

This function takes a string as input and splits it by comma to get a list of values. Then, it removes the quotation marks from each value using a list comprehension. Finally, it returns the list of values. 

Example usage:

```python
>>> extract_values('"Python", "PHP", "Java"')
['Python', 'PHP', 'Java']
``` 