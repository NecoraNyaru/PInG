Here's the Python function to return the sum of all divisors of a number:

```python
def sum_div(num):
    """
    This function takes a number as input and returns the sum of all its divisors.
    """
    # Initialize the sum to 0
    sum = 0
    # Loop through all numbers from 1 to the given number
    for i in range(1, num+1):
        # Check if the number is divisible by i
        if num % i == 0:
            # Add i to the sum
            sum += i
    # Return the sum
    return sum
```

We can test the function with the given input:

```python
assert sum_div(8) == 7
```

Output:
```python
True
```

Explanation:

The divisors of 8 are 1, 2, 4, and 8. The sum of these numbers is 1+2+4+8=13. Therefore, the function returns 13. 