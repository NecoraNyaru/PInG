Here's a possible solution to the problem:

```python
def search(arr):
    # Initialize variables to keep track of the previous and current elements
    prev = arr[0]
    curr = arr[1]
    
    # Loop through the array starting from the second element
    for i in range(1, len(arr)):
        # If the current element is different from the previous element, return it
        if curr != prev:
            return curr
        # Otherwise, update the previous and current elements
        prev = curr
        curr = arr[i+1]
    
    # If we reach the end of the array without finding a different element, return the last element
    return curr
```

This solution works by iterating through the array and comparing each element with the previous one. If they are different, we know that the current element is the one that appears only once. If they are the same, we continue iterating until we find a different element or reach the end of the array. If we reach the end of the array without finding a different element, the last element is the one that appears only once. The time complexity of this solution is O(n), where n is the length of the array. 