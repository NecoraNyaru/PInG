Here's a possible solution:

```python
def two_unique_nums(lst):
    unique_lst = []
    for num in lst:
        if num not in unique_lst:
            unique_lst.append(num)
    return unique_lst
```

This function takes a list of numbers as input and returns a new list with only the unique numbers. It works by iterating over each number in the input list and checking if it's already in the `unique_lst` list. If it's not, it adds it to the list. If it is, it skips it. This ensures that only the first occurrence of each number is kept in the output list. 