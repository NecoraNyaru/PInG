Here's the Python function to find the length of the longest word in a list of words:

```python
def len_log(words):
    max_length = 0
    for word in words:
        if len(word) > max_length:
            max_length = len(word)
    return max_length
```

This function takes a list of words as input and iterates through each word in the list. If the length of the current word is greater than the current maximum length, it updates the maximum length. Finally, it returns the maximum length found. In this case, the function will return 7 for the input ["python","PHP","bigdata"]. 