Here's the Python code for the function to locate the right insertion point for a specified value in a sorted list:

```python
def right_insertion(lst, val):
    left = 0
    right = len(lst) - 1
    while left <= right:
        mid = (left + right) // 2
        if lst[mid] < val:
            left = mid + 1
        else:
            right = mid - 1
    return left
```

This function takes a sorted list `lst` and a value `val` as input. It uses binary search to find the right insertion point for `val` in the list. The function returns the index of the rightmost element in the list that is less than or equal to `val`. If `val` is less than all elements in the list, it returns 0. If `val` is greater than all elements in the list, it returns the length of the list. Otherwise, it returns the index of the first element that is greater than `val`.

Here's how it works:

1. Initialize `left` and `right` to the first and last indices of the list, respectively.
2. While `left` is less than or equal to `right`, calculate the midpoint `mid` of the list.
3. If the value at `mid` is less than `val`, move `left` to `mid + 1`. This means that `val` should be inserted between `lst[left-1]` and `lst[mid]`.
4. If the value at `mid` is greater than or equal to `val`, move `right` to `mid - 1`. This means that `val` should be inserted between `lst[mid]` and `lst[right]`.
5. Repeat steps 2 and 3 until `left` is greater than `right`.
6. Return `left`.

Here's how you can test the function:

```python
assert right_insertion([1,2,4,5],6) == 4
```

This should return `4`, since the right insertion point for `6` in `[1,2,4,5]` is between `4` and `5`. 