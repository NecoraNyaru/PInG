Here's the Python code to find the perimeter of a regular pentagon from the length of its sides:

```python
def perimeter_pentagon(side_length):
    return 5 * side_length
```

This function takes in the length of one side of the pentagon as an argument and returns the perimeter of the pentagon, which is simply the product of the number of sides and the length of each side. In this case, since a regular pentagon has 5 sides, the perimeter is 5 times the length of the side. Therefore, the function simply returns 5 times the input value. 

To test the function, we can call it with the value 5 and check if it returns the expected output:

```python
assert perimeter_pentagon(5) == 25
```

This will pass the assertion test because the perimeter of a regular pentagon with side length 5 is 25. 