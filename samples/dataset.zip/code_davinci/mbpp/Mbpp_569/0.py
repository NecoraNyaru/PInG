Here's the Python script to sort each sublist of strings in a given list of lists:

```python
def sort_sublists(lst):
    for i in range(len(lst)):
        lst[i].sort()
    return lst
```

This function takes a list of lists as input and sorts each sublist in ascending order using the `sort()` method. The sorted sublists are then returned as output. For example:

```python
>>> sort_sublists([['green', 'orange'], ['black', 'white'], ['white', 'black', 'orange']])
[['green', 'orange'], ['black', 'white'], ['black', 'orange', 'white']]
```

Note that the input list is modified in place, so if you want to keep the original list intact, you can make a copy of it before passing it to the function. 