Here's the Python script to filter odd numbers from a list:

```python
def filter_oddnumbers(lst):
    return [num for num in lst if num % 2 != 0]
```

This function takes a list as an argument and returns a new list containing only the odd numbers from the original list. It uses a list comprehension to iterate over each element in the list and checks if it is odd or not using the modulo operator `%`. If the remainder of the division of the number by 2 is not equal to 0, it is included in the new list. 