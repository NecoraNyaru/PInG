Here's the Python script to join a list of multiple integers into a single integer:

```python
def multiple_to_single(lst):
    """
    This function takes a list of integers as input and returns a single integer by joining them together.
    """
    result = ""
    for num in lst:
        result += str(num)
    return int(result)
```

We can test the function with the given example:

```python
assert multiple_to_single([11, 33, 50]) == 113350
```

Output:
```python
True
``` 