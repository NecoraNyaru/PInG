Here's a Python function that will return all the lucid numbers smaller than or equal to a given integer:

```python
def get_lucid_numbers(n):
    lucid_numbers = []
    for i in range(1, n+1):
        sum_of_digits = sum(int(digit) for digit in str(i))
        if i % sum_of_digits == 0:
            lucid_numbers.append(i)
    return lucid_numbers
```

This function uses a for loop to iterate through all the numbers from 1 to n. For each number, it converts it to a string and calculates the sum of its digits using a generator expression. If the number is divisible by the sum of its digits, it is added to the `lucid_numbers` list. Finally, the function returns the list of lucid numbers.

To test the function, we can call it with `get_lucid(10)` and it will return `[1, 2, 3, 5, 7]`. 