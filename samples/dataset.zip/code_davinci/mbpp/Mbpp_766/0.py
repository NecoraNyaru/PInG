Here's the Python code to solve the problem:

```python
def pair_wise(lst):
    return [(lst[i], lst[i+1]) for i in range(len(lst)-1)]
```

This function takes a list as input and returns a list of tuples containing all consecutive pairs of items in the list. We use a list comprehension to iterate over the list and create a tuple for each pair of consecutive items. The `range()` function is used to generate the indices of the list, and we subtract 1 from the length of the list to avoid going out of bounds. The resulting list of tuples is returned. 