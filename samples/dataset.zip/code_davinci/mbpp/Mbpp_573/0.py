Here's the Python function to calculate the product of the unique numbers in a given list:

```python
def unique_product(lst):
    unique_nums = set(lst)
    product = 1
    for num in unique_nums:
        product *= num
    return product
```

Explanation:

- We first convert the list to a set to remove any duplicates using the `set()` function.
- We then iterate through the set and multiply each number to get the product.
- Finally, we return the product.

Example:

```python
>>> unique_product([10, 20, 30, 40, 20, 50, 60, 40])
72000000
```

Note: This function assumes that the list contains only integers. If the list contains other data types, you may need to modify the function to handle them appropriately. 