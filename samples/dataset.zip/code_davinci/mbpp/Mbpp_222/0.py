Here's the Python script to check if all the elements in a tuple have the same data type:

```python
def check_type(tup):
    """
    This function takes a tuple as input and returns True if all the elements in the tuple have the same data type, else False.
    """
    # Get the data type of the first element in the tuple
    first_type = type(tup[0])
    # Loop through the tuple and check if all the elements have the same data type as the first element
    for i in tup:
        if type(i) != first_type:
            return False
    return True
```

We can test the function with the given example:

```python
assert check_type((5, 6, 7, 3, 5, 6) ) == True
```

Output:
```python
True
``` 