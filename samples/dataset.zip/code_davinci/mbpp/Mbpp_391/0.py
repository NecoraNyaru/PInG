Here's the Python script to convert multiple lists to a nested dictionary:

```python
def convert_list_dictionary(students, subjects, grades):
    result = {}
    for i in range(len(students)):
        result[students[i]] = {subjects[i]: grades[i]}
    return result
```

This function takes in three lists as input: `students`, `subjects`, and `grades`. It initializes an empty dictionary `result`. Then, it iterates over the length of the `students` list using a `for` loop. For each index `i`, it creates a new dictionary with the `students[i]` as the key and the `subjects[i]` as the key of the nested dictionary. The value of the nested dictionary is the `grades[i]`. Finally, it returns the `result` dictionary. 