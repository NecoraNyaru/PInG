Here's the Python script to find words that are longer than n characters from a given list of words:

```python
def long_words(n, sentence):
    words = sentence.split()
    long_words = []
    for word in words:
        if len(word) > n:
            long_words.append(word)
    return long_words
```

This function takes two arguments: `n` and `sentence`. `n` is the minimum length of the words we want to find, and `sentence` is the string of words we want to search through. We split the sentence into a list of words using the `split()` method, and then loop through each word in the list. If the length of the word is greater than `n`, we append it to the `long_words` list. Finally, we return the `long_words` list. 