Here's the Python script to get the frequency of all the elements in a list as a dictionary:

```python
def freq_count(lst):
    freq = {}
    for i in lst:
        if i in freq:
            freq[i] += 1
        else:
            freq[i] = 1
    return freq
```

This function takes a list as input and creates an empty dictionary `freq`. It then iterates through each element in the list and checks if it already exists as a key in the dictionary. If it does, it increments the value by 1. If it doesn't, it adds the element as a key with a value of 1. Finally, it returns the dictionary with the frequency of each element. 