Here's the Python function to find the maximum absolute product between numbers in pairs of tuples within a given list:

```python
def max_product_tuple(lst):
    max_product = 0
    for i in range(len(lst)):
        for j in range(i+1, len(lst)):
            product = abs(lst[i][0] * lst[j][0]) * abs(lst[i][1] * lst[j][1])
            if product > max_product:
                max_product = product
    return max_product
```

Explanation:

We iterate through the list using two nested loops. For each pair of tuples, we calculate the product of their elements and take the absolute value of the product. We compare the product with the current maximum product and update it if the current product is greater than the current maximum product. Finally, we return the maximum product. 