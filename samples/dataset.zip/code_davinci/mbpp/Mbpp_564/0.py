Here's the Python function that counts the number of possible unordered pairs where both elements are unequal:

```python
def count_Pairs(lst):
    count = 0
    for i in range(len(lst)):
        for j in range(i+1, len(lst)):
            if lst[i] != lst[j]:
                count += 1
    return count
```

This function takes a list of integers as input and iterates through each pair of elements in the list. If both elements are not equal, it increments the count variable. Finally, it returns the count of such pairs. For example, if the input list is [1,2,1], the function will iterate through (1,2) and (2,1) and return 2 as there are two such pairs. 