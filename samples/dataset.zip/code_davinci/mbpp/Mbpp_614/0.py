Here's the Python code to find the cumulative sum of all the values that are present in the given tuple list:

```python
def cummulative_sum(lst):
    total = 0
    for tup in lst:
        for num in tup:
            total += num
    return total

print(cummulative_sum([(1, 3), (5, 6, 7), (2, 6)])) # Output: 20
```

Explanation:

We first initialize a variable `total` to 0. Then, we loop through each tuple in the list `lst` using a for loop. For each tuple, we loop through its values using another for loop and add each value to the `total` variable. Finally, we return the `total` variable which contains the cumulative sum of all the values in the list. 