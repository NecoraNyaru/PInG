Here's the Python function to count the number of pairs whose xor value is odd:

```python
def find_Odd_Pair(arr, n):
    count = 0
    for i in range(n):
        for j in range(i+1, n):
            if (arr[i]^arr[j])%2!=0:
                count+=1
    return count
```

Explanation:

We iterate through the array and for each pair of elements, we calculate their xor value and check if it's odd or not. If it's odd, we increment the count. Finally, we return the count as the output. 