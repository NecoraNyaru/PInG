Here's a possible solution:

```python
def removezero_ip(ip):
    return '.'.join(str(int(i) for i in ip.split('.') if i != '0')
```

This function takes an IP address as input and returns a new IP address with leading zeroes removed. It works by splitting the IP address into its four parts using the `.split('.')` method, converting each part to an integer using a list comprehension, and then filtering out any parts that are equal to `'0'`. Finally, it joins the remaining parts back together with a period using the `.join()` method.

For example:

```python
>>> removezero_ip("216.08.094.196")
'216.8.94.196'
```

Note that this function assumes that the input is a valid IP address in dotted-decimal notation. If the input is not a valid IP address, it may raise a `ValueError` or return an unexpected result. 