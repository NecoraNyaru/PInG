Here's the Python function to interchange the first and last elements in a list:

```python
def swap_List(lst):
    lst[0], lst[-1] = lst[-1], lst[0]
    return lst
```

This function takes a list as input and swaps the first and last elements using tuple unpacking. The first element of the list is assigned to the last element and the last element is assigned to the first element. The modified list is then returned. 

Example:

```python
>>> swap_List([12, 35, 9, 56, 24])
[24, 35, 9, 56, 12]
```

Note: This function modifies the original list and does not create a new list. If you want to create a new list, you can use slicing to create a new list with the swapped elements:

```python
def swap_List(lst):
    return [lst[-1]] + lst[1:-1] + [lst[0]]
```

This function creates a new list by slicing the original list and adding the last element to the beginning, followed by all the elements except the first and last, and finally adding the first element to the end. 