Here's the Python function to find the average of cubes of first n natural numbers:

```python
def find_Average_Of_Cube(n):
    sum = 0
    for i in range(1, n+1):
        sum += i**3
    return sum/n
```

Explanation:
- We initialize a variable `sum` to 0.
- We use a for loop to iterate from 1 to n+1.
- For each iteration, we cube the current number and add it to the `sum` variable.
- Finally, we divide the `sum` by `n` and return the result.

Example:
```python
>>> find_Average_Of_Cube(2)
4.5
```

This function will return the average of cubes of first two natural numbers, which is 1^3 + 2^3 = 1 + 8 = 9 and 9/2 = 4.5. 