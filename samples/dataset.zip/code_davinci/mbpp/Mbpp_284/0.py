Here's the Python script for the given problem:

```python
def check_element(lst, element):
    """
    This function takes in a list and an element and checks whether all items in the list are equal to the given element.
    """
    for item in lst:
        if item != element:
            return False
    return True
```

We can test the function using the following code:

```python
assert check_element(["green", "orange", "black", "white"], 'blue') == False
```

This will return `False` because not all items in the list are equal to the given element. 