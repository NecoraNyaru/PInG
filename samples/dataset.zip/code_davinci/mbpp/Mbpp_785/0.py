Here's a Python function that converts a tuple string to an integer tuple:

```python
def tuple_str_int(tup_str):
    # Remove the parentheses and split the string into a list of strings
    tup_str_list = tup_str.strip('()').split(',')
    # Convert each string to an integer and append it to a new list
    int_list = [int(i.strip()) for i in tup_str_list]
    # Convert the list of integers to a tuple and return it
    return tuple(int_list)
```

This function takes a string representing a tuple as input and first removes the parentheses and splits it into a list of strings. It then uses a list comprehension to convert each string to an integer and append it to a new list. Finally, it converts the list to a tuple and returns it. Here's how you can test it:

```python
assert tuple_str_int("(7, 8, 9)") == (7, 8, 9)
```

This should return `True` since the function should return a tuple of integers `(7, 8, 9)`. 