Here's a Python function that converts complex numbers to polar coordinates:

```python
import cmath

def convert(z):
    r = abs(z)
    theta = cmath.phase(z)
    return (r, theta)
```

This function takes a complex number `z` as input and returns a tuple containing its magnitude `r` and phase `theta` in radians. The `abs()` function is used to calculate the magnitude of the complex number, and the `phase()` function is used to calculate the phase in radians. The `cmath` module is used to access the `phase()` function. The function can be tested with the example input `1`, which should return `(1.0, 0.0)`. 