Here's the Python code for the function:

```python
def sum_series(n):
    total = 0
    for i in range(n//2 + 1):
        total += n - 2*i
    return total
```

This function takes an integer `n` as input and initializes a variable `total` to 0. It then uses a `for` loop to iterate over the range from 0 to `n//2 + 1`, which is the same as `n/2` rounded down. For each value of `i` in the range, it adds `(n - 2*i)` to the `total` variable. The `//` operator is used to perform integer division, so that the loop only goes up to `n/2`. Finally, the function returns the total sum.

For example, `sum_series(6)` would iterate over the values `0`, `1`, `2`, `3`, and `4`, adding `6`, `4`, `2`, and `0` to `total`, respectively, resulting in a final value of `12`. 