Here's a Python function that converts RGB color to HSV color:

```python
def rgb_to_hsv(r, g, b):
    # Convert RGB to HSV
    r, g, b = r/255.0, g/255.0, b/255.0
    cmax = max(r, g, b)
    cmin = min(r, g, b)
    delta = cmax - cmin
    if delta == 0:
        h = 0
    elif cmax == r:
        h = ((g - b) / delta) % 6
    elif cmax == g:
        h = (b - r) / delta + 2
    else:
        h = (r - g) / delta + 4
    h = round(h * 60)
    if h < 0:
        h += 360
    v = cmax
    s = 0 if cmax == 0 else delta / cmax
    return h, s, v
```

This function takes in the red, green, and blue values as arguments and returns the HSV values as a tuple. The HSV values are rounded to two decimal places. The formula used to convert RGB to HSV is the same as the one given in the link provided. The function first normalizes the RGB values by dividing them by 255.0 to get values between 0 and 1. It then calculates the maximum and minimum values of the RGB values and finds the delta between them. The H value is calculated based on the maximum and minimum values and the delta. The S value is calculated as the delta divided by the maximum value. The V value is simply the maximum value.

To test the function, we can use the assert statement provided in the problem statement:

```python
assert rgb_to_hsv(255, 255, 255) == (0, 0.0, 100.0)
```

This will check if the function returns the expected output for the given input. If the output is correct, the assert statement will return True, otherwise it will raise an AssertionError. 