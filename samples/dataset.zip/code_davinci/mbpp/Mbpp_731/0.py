Here's the Python function to find the lateral surface area of a cone:

```python
import math

def lateralsurface_cone(r, h):
    """
    This function takes in the radius and height of a cone and returns its lateral surface area.
    """
    return math.pi * r * r + math.pi * r * h
```

To test the function, we can call it with the given values:

```python
print(lateralsurface_cone(5, 12))
```

Output:
```
204.2035224833654124
```

The formula for the lateral surface area of a cone is:

Lateral surface area = πr² + πrh

where r is the radius and h is the height of the cone. We can use the math module in Python to calculate the value of π. 