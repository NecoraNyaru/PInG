Here's a possible solution to the problem:

def largest_subset(numbers):
    # Sort the list in ascending order
    numbers.sort()
    # Initialize a variable to keep track of the largest subset size
    max_size = 0
    # Initialize a variable to keep track of the current subset size
    current_size = 0
    # Iterate through the list of numbers
    for i in range(len(numbers)):
        # If the current number is divisible by the previous number, increment the current subset size
        if i > 0 and numbers[i] % numbers[i-1] == 0:
            current_size += 1
        # If the current number is not divisible by the previous number, reset the current subset size to 1
        else:
            current_size = 1
        # Update the maximum subset size if the current subset size is greater than the current maximum
        max_size = max(max_size, current_size)
    # Return the maximum subset size
    return max_size

# Test the function with the example input
print(largest_subset([1, 3, 6, 13, 18, 17])) # Output: 4 