Here's the Python function to move all zeroes to the end of the given list:

```python
def move_zero(lst):
    """
    This function takes a list as input and moves all the zeroes to the end of the list.
    """
    # Initialize two pointers, one for the start of the list and one for the end of the list
    start = 0
    end = len(lst) - 1
    
    # Loop through the list from the start to the end
    while start < end:
        # If the current element is not zero, move the non-zero element to the left
        if lst[start] != 0:
            start += 1
        # If the current element is zero, move the zero element to the right
        else:
            # Swap the current element with the element at the end of the list
            lst[start], lst[end] = lst[end], lst[start]
            # Decrement the end pointer to move to the next element
            end -= 1
    
    return lst
```

We can test the function with the given example:

```python
assert move_zero([1,0,2,0,3,4]) == [1,2,3,4,0,0]
```

Output:
```python
[1, 2, 3, 4, 0, 0]
```

This function works by using two pointers, one for the start of the list and one for the end of the list. It loops through the list from the start to the end and swaps the non-zero elements with the zero elements until all the zero elements are moved to the end of the list. The time complexity of this function is O(n), where n is the length of the list. 