Here's the Python script to find the sum and average of the first n natural numbers:

```python
def sum_average(n):
    sum = 0
    for i in range(1, n+1):
        sum += i
    average = sum / n
    return (sum, average)

print(sum_average(10)) # Output: (55, 5.5)
```

Explanation:

- We define a function `sum_average` that takes an integer `n` as input.
- We initialize a variable `sum` to 0, which will be used to store the sum of the first n natural numbers.
- We use a `for` loop to iterate from 1 to n+1 and add each number to the `sum` variable.
- We calculate the average by dividing the `sum` by `n`.
- Finally, we return a tuple containing the sum and average of the first n natural numbers. 