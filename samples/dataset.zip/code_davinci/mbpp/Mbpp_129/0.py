Here's a Python function that checks if a given matrix is a magic square:

```python
def magic_square_test(matrix):
    n = len(matrix)
    magic_sum = sum(range(1, n**2+1))
    
    # Check if the sum of each row is equal to the magic sum
    for row in matrix:
        if sum(row) != magic_sum:
            return False
    
    # Check if the sum of each column is equal to the magic sum
    for i in range(n):
        if sum(matrix[j][i] for j in range(n)) != magic_sum:
            return False
    
    # Check if the sum of the diagonal is equal to the magic sum
    if sum(matrix[i][i] for i in range(n)) != magic_sum:
        return False
    
    # Check if the sum of the anti-diagonal is equal to the magic sum
    if sum(matrix[i][n-i-1] for i in range(n)) != magic_sum:
        return False
    
    return True
```

This function takes a matrix as input and returns True if it is a magic square, and False otherwise. It first calculates the magic sum, which is the sum of all numbers from 1 to n^2. Then, it checks if each row, column, and diagonal of the matrix has the same sum as the magic sum. If any of these conditions fail, the function returns False. If all conditions pass, it returns True. 