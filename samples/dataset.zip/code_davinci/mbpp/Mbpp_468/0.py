Here's a Python function that finds the maximum product of an increasing subsequence in an array:

```python
def max_product(arr):
    n = len(arr)
    if n == 0:
        return 0
    elif n == 1:
        return arr[0]
    elif n == 2:
        return max(arr[0], arr[1])
    else:
        max_product = arr[0]
        min_product = arr[0]
        result = arr[0]
        for i in range(1, n):
            if arr[i] > max_product:
                max_product = arr[i]
            elif arr[i] < min_product:
                min_product = arr[i]
            result = max(result * max_product, result * min_product)
            if result < 0:
                result = max(result * arr[i], max_product * min_product)
        return result
```

This function works by iterating through the array and keeping track of the maximum and minimum values seen so far. It also keeps track of the current result, which is the maximum product of the current subsequence. If the current number is greater than the maximum product seen so far, it becomes the new maximum product. If the current number is less than the minimum product seen so far, it becomes the new minimum product. The result is updated to be the maximum of the current result and the maximum product times the minimum product. If the result is negative, it is updated to be the maximum of the current result and the maximum product times the minimum product. This ensures that the result is always positive. Finally, the function returns the maximum of the result and the maximum product seen so far. This approach works because the maximum product of an increasing subsequence is either the current number or the maximum product times the minimum product seen so far. 