Here's the Python code for the given problem:

```python
def split_list(lst, n):
    """
    This function takes in a list and an integer n and returns a list of lists containing every nth element of the original list.
    """
    result = []
    for i in range(0, len(lst), n):
        result.append(lst[i:i+n])
    return result
```

Example:

```python
>>> split_list(['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n'], 3)
[['a', 'd', 'g', 'j', 'm'], ['b', 'e', 'h', 'k', 'n'], ['c', 'f', 'i', 'l']]
```

Explanation:

The function `split_list()` takes in a list `lst` and an integer `n`. It initializes an empty list `result` to store the sublists. It then uses a `for` loop to iterate over the list `lst` with a step of `n` using the `range()` function. The `range()` function starts from 0 and goes up to the length of the list `lst` with a step of `n`. This ensures that we get every nth element of the list. The sublist is created using slicing and appended to the `result` list. Finally, the `result` list is returned. 