Here's a Python function that checks if a given number is a woodball or not:

```python
def is_woodall(num):
    # Convert the number to a string and check if it has only digits
    if not num.isdigit():
        return False
    
    # Convert the number to a list of digits
    digits = [int(d) for d in str(num)]
    
    # Check if the sum of digits is equal to the product of digits
    if sum(digits) == num:
        return True
    else:
        return False
```

This function first checks if the input is a valid number by checking if it contains only digits. If it is not a valid number, it returns False. If it is a valid number, it converts it to a list of digits and checks if the sum of the digits is equal to the product of the digits. If it is, it returns True, otherwise it returns False. For example:

```python
>>> is_woodall(383)
True
>>> is_woodall(123)
False
>>> is_woodall(1234)
False
>>> is_woodall(12345)
False
```

Note that this function assumes that the input is a positive integer. If you want to support negative numbers or non-integer inputs, you may need to modify it accordingly. 