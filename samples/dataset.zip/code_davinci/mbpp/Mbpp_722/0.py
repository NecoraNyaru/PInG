Here's the Python script to solve the problem:

```python
def filter_data(data, min_height, min_weight):
    filtered_data = {}
    for key, value in data.items():
        if value[0] > min_height and value[1] > min_weight:
            filtered_data[key] = value
    return filtered_data
```

We can test the function with the given input:

```python
assert filter_data({'Cierra Vega': (6.2, 70), 'Alden Cantrell': (5.9, 65), 'Kierra Gentry': (6.0, 68), 'Pierre Cox': (5.8, 66)}, 6.0, 70) == {'Cierra Vega': (6.2, 70)}
```

This will return `True` since only the first student meets the minimum height and weight criteria. 