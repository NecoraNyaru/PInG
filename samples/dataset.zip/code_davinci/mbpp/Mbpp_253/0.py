Here's the Python function that counts the number of integer elements in a given list:

```python
def count_integer(lst):
    count = 0
    for element in lst:
        if isinstance(element, int):
            count += 1
    return count
```

This function takes a list as an argument and iterates through each element in the list. If an element is an integer, it increments the count variable. Finally, it returns the count of integer elements in the list. 