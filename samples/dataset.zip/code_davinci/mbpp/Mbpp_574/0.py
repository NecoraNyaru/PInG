Here's the Python function to find the surface area of a cylinder:

```python
def surfacearea_cylinder(radius, height):
    """
    This function takes in the radius and height of a cylinder and returns its surface area.
    """
    surface_area = 2 * 3.14 * radius * (radius + height)
    return surface_area
```

To test the function, we can call it with the given values of radius=10 and height=5:

```python
assert surfacearea_cylinder(10, 5) == 942.45
```

This will return True since the surface area of a cylinder with radius 10 and height 5 is approximately 942.45 square units. 