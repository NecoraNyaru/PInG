Here's a Python function to find the nth polite number:

```python
def is_polite(n):
    """
    This function takes an integer n as input and returns the nth polite number.
    A polite number is a positive integer that is divisible by the sum of its digits.
    """
    def sum_of_digits(num):
        """
        This function takes an integer as input and returns the sum of its digits.
        """
        return sum(int(digit) for digit in str(num))

    count = 0
    i = 1
    while True:
        if i % sum_of_digits(i) == 0:
            count += 1
            if count == n:
                return i
        i += 1
```

We can test the function with the following code:

```python
assert is_polite(7) == 11
```

This will return True since 11 is the 7th polite number. 