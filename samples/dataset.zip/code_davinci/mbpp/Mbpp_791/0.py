Here's the Python script to remove tuples from the given tuple:

```python
def remove_nested(tup):
    """
    This function takes a tuple as input and returns a new tuple with all nested tuples removed.
    """
    new_tup = []
    for item in tup:
        if type(item) == tuple:
            for sub_item in item:
                new_tup.append(sub_item)
        else:
            new_tup.append(item)
    return tuple(new_tup)
```

Explanation:

We define a function `remove_nested` that takes a tuple `tup` as input. We create an empty list `new_tup` to store the flattened tuple. We iterate over each item in the input tuple `tup`. If the item is a tuple, we iterate over its sub-items and append them to `new_tup`. If the item is not a tuple, we simply append it to `new_tup`. Finally, we convert `new_tup` to a tuple and return it. This function will return a new tuple with all nested tuples removed. 

Example:

```python
>>> remove_nested((1, 5, 7, (4, 6), 10))
(1, 5, 7, 4, 6, 10)
```

Note that this function will only remove one level of nested tuples. If there are nested tuples within nested tuples, they will not be removed. 