Here's a Python function that finds the number of divisors of a given integer:

```python
def divisor(n):
    count = 0
    for i in range(1, n+1):
        if n % i == 0:
            count += 1
    return count
```

This function uses a for loop to iterate through all the numbers from 1 to n and checks if each number is a divisor of n. If it is, it increments the count variable. Finally, it returns the count of divisors. For example, if n is 15, the function will iterate through 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, and 15, and return 4 because 15 has 4 divisors: 1, 3, 5, and 15. 