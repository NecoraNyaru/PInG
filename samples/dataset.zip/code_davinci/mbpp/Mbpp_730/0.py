Here's the Python script to remove consecutive duplicates from a given list:

```python
def remove_consecutive_duplicates(lst):
    result = []
    for i in lst:
        if i not in result or i != result[-1]:
            result.append(i)
    return result

# Testing the function
assert remove_consecutive_duplicates([0, 0, 1, 2, 3, 4, 4, 5, 6, 6, 7, 8, 9, 4, 4]) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 4]
```

Explanation:

We iterate through the given list `lst` and check if the current element `i` is not already in the `result` list or if it is not equal to the last element of `result`. If it is not, we append it to the `result` list. This way, we remove all consecutive duplicates from the list. Finally, we return the `result` list. 