Here's a Python function that sorts a list of elements using the pancake sorting algorithm:

```python
def pancake_sort(lst):
    n = len(lst)
    
    # Perform bubble sort to sort the list in ascending order
    for i in range(n):
        for j in range(0, n-i-1):
            if lst[j] > lst[j+1]:
                lst[j], lst[j+1] = lst[j+1], lst[j]
    
    # Reverse the list to sort it in descending order
    lst = lst[::-1]
    
    # Perform bubble sort again to sort the list in ascending order
    for i in range(n):
        for j in range(0, n-i-1):
            if lst[j] < lst[j+1]:
                lst[j], lst[j+1] = lst[j+1], lst[j]
    
    return lst
```

This function first performs a bubble sort to sort the list in ascending order. Then, it reverses the list and performs another bubble sort to sort it in descending order. Finally, it returns the sorted list. The time complexity of this algorithm is O(n^2), which is not the most efficient for large lists, but it works well for small lists. 