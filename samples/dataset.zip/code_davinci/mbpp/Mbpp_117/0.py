Here's a possible solution:

def list_to_float(lst):
    result = []
    for sublist in lst:
        new_sublist = []
        for element in sublist:
            try:
                new_sublist.append(float(element))
            except ValueError:
                new_sublist.append(element)
        result.append(tuple(new_sublist))
    return result

# Test the function
assert list_to_float([("3", "4"), ("1", "26.45"), ("7.32", "8"), ("4", "8")]) == [(3.0, 4.0), (1.0, 26.45), (7.32, 8.0), (4.0, 8.0)]

# Test the function with a different input
assert list_to_float([("3", "4", "5"), ("1", "26.45", "7"), ("7.32", "8", "10"), ("4", "8", "12.5")]) == [(3.0, 4.0, 5.0), (1.0, 26.45, 7.0), (7.32, 8.0, 10.0), (4.0, 8.0, 12.5)]

# Test the function with an empty list
assert list_to_float([]) == []

# Test the function with a list of empty sublists
assert list_to_float([[], [], []] == [[], [], []]

# Test the function with a list of sublists of different lengths
assert list_to_float([[1, 2, 3], [4, 5, 6, 7], [8, 9]] == [(1.0, 2.0, 3.0), (4.0, 5.0, 6.0), (8.0, 9.0)] 