Here's the Python code for the function:

```python
def insert_element(lst, elem):
    return [elem] + lst
```

This function takes in a list `lst` and an element `elem`, and returns a new list that consists of the element `elem` followed by all the elements in `lst`. The `+` operator concatenates the two lists together, so the new list is created by adding the element `elem` to the beginning of the original list `lst`. The `return` statement returns this new list. 