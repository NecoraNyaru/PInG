Here's the Python script to find the size in bytes of a given tuple:

```python
import sys

def tuple_size(tup):
    return sys.getsizeof(tup)
```

This function takes a tuple as an argument and returns the size of the tuple in bytes using the `sys.getsizeof()` function. The `sys.getsizeof()` function returns the size of an object in bytes. We can use this function to find the size of the tuple in bytes. The `assert` statement is used to test the function with the given example. If the function returns the correct size, the test will pass. 