Here's the Python function to find the next perfect square greater than a given number:

```python
def next_Perfect_Square(num):
    """
    This function takes a number as input and returns the next perfect square greater than the given number.
    """
    # Find the square root of the number
    sqrt_num = int(num ** 0.5)
    # If the square root is an integer, return the next perfect square
    if sqrt_num ** 2 == num:
        return (sqrt_num + 1) ** 2
    # If the square root is not an integer, return the next integer square
    else:
        return (sqrt_num + 1) ** 2
```

We first find the square root of the given number using the `**` operator. If the square root is an integer, we return the next perfect square by adding 1 to it and squaring it. If the square root is not an integer, we return the next integer square by adding 1 to it and squaring it. 