Here's a Python function to find the nth nonagonal number:

```python
def is_nonagonal(n):
    return n * (n * n * (n * 2 - 1)
```

This function takes an integer `n` as input and returns the nth nonagonal number. The formula for the nth nonagonal number is `n * (n * n * (n * 2 - 1)`. We can use this formula to calculate the nth nonagonal number by multiplying `n` by itself squared, and then multiplying that result by `(n * 2 - 1)`. This formula works because the nonagonal number is the sum of the squares of the first `n` odd numbers. For example, the first nonagonal number is 1^2 + 3^2 = 10, the second nonagonal number is 1^2 + 3^2 + 5^2 = 16, and so on. 