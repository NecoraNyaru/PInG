Here's the Python script to add a tuple to a list:

```python
def add_tuple(lst, tup):
    lst += list(tup)
    return lst
```

This function takes in two arguments: `lst` and `tup`. `lst` is the list to which we want to add the tuple, and `tup` is the tuple that we want to add to the list. We use the `+=` operator to concatenate the list and tuple, and then return the resulting list. The `list()` function is used to convert the tuple to a list so that we can add it to the original list. 