Here's a Python function that checks if the given expression is balanced or not:

```python
def check_expression(expression):
    stack = []
    for char in expression:
        if char in ["(", "{", "["]:
            stack.append(char)
        elif char in [")", "}", "]"]:
            if not stack:
                return False
            if (char == ")" and stack[-1] == "(") or (char == "}" and stack[-1] == "{") or (char == "]" and stack[-1] == "["):
                stack.pop()
            else:
                return False
    return not stack
```

This function uses a stack to keep track of opening brackets. If an opening bracket is encountered, it is pushed onto the stack. If a closing bracket is encountered, it is checked against the top of the stack to see if it matches the corresponding opening bracket. If it does, the opening bracket is popped from the stack. If the stack is empty at the end of the expression, then the expression is balanced. If there are any remaining opening brackets at the end of the expression, it is not balanced. The function returns `True` if the expression is balanced, and `False` otherwise. 