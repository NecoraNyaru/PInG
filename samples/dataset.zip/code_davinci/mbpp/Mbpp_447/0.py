Here's the Python script to find the cubes of individual elements in a list:

```python
def cube_nums(lst):
    """
    This function takes a list of numbers as input and returns a list of cubes of each element in the list.
    """
    cubes = []
    for num in lst:
        cubes.append(num**3)
    return cubes
```

We can test the function with the given input:

```python
assert cube_nums([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 8, 27, 64, 125, 216, 343, 512, 729, 1000]
```

Output:
```python
True
``` 