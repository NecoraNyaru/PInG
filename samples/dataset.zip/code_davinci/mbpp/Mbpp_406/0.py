Here's the Python function to find whether the parity of a given number is odd or even:

```python
def find_Parity(num):
    if num % 2 == 0:
        return True
    else:
        return False
```

This function takes a number as input and returns True if the number is even and False if it's odd. It does this by checking if the remainder of the number divided by 2 is 0. If the remainder is 0, then the number is even, otherwise it's odd. 