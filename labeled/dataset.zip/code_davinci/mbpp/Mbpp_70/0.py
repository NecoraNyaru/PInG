Here's the Python code to solve the problem:

```python
def get_equal(tuples):
    """
    This function takes a list of tuples as input and returns True if all the tuples have equal length, else False.
    """
    if len(set(len(t) for t in tuples)) == 1:
        return True
    else:
        return False
```

Explanation:

We use a set to store the lengths of all the tuples in the list. If the length of the set is 1, it means all the tuples have the same length. If not, then the set will have more than one element, which means there are tuples with different lengths. We return True if the length of the set is 1, else False. 