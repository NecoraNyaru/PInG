Here's a possible solution:

```python
def is_decimal(num_str):
    try:
        num = float(num_str)
        if num.is_integer():
            return False
        else:
            return round(num, 2) == num
    except ValueError:
        return False
```

Explanation:

The `is_decimal` function takes a string `num_str` as input and tries to convert it to a float using the `float()` function. If the conversion is successful, it checks whether the float is an integer (i.e., whether it has no decimal part) using the `is_integer()` method. If it is, then the function returns `False`, since the string is not a decimal with a precision of 2. If the float has a decimal part, it rounds it to 2 decimal places using the `round()` function and compares it to the original float. If they are equal, then the string is a decimal with a precision of 2, so the function returns `True`. If the conversion fails (e.g., because the string contains non-numeric characters), the function returns `False`. 