Here's a Python function that takes a binary string and a number of rotations as input and returns the number of odd digits in the rotated binary string:

```python
def odd_Equivalent(binary_string, rotations):
    # Convert the binary string to a list of integers
    binary_list = [int(bit) for bit in binary_string]
    
    # Rotate the list by the given number of rotations
    rotated_list = binary_list[-rotations:] + binary_list[:-rotations]
    
    # Count the number of odd digits in the rotated list
    odd_count = sum(1 for bit in rotated_list if bit % 2 == 1)
    
    return odd_count
```

This function first converts the binary string to a list of integers using a list comprehension. It then rotates the list by slicing it using negative indices to shift the bits to the right by the given number of rotations. Finally, it counts the number of odd digits in the rotated list using a generator expression and the built-in `sum()` function. The `sum()` function returns the total number of odd digits in the rotated list. 