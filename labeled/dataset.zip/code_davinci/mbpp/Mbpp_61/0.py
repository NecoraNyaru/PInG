Here's a Python function that counts the number of substrings with the sum of digits equal to their length:

```python
def count_substrings(s):
    count = 0
    n = len(s)
    for i in range(n):
        for j in range(i+1, n+1):
            substring = s[i:j]
            if sum(int(d) for d in substring) == len(substring):
                count += 1
    return count
```

This function takes a string `s` as input and iterates through all possible substrings of `s`. For each substring, it calculates the sum of its digits and compares it to the length of the substring. If the sum is equal to the length, it increments the count. Finally, it returns the count.

For example, `count_substrings('112112')` would return `6`, because there are six substrings that satisfy the condition: '1', '11', '112', '121', '211', '1121', and '1211'. 