Here's a Python function to find the volume of a sphere:

```python
import math

def volume_sphere(radius):
    return (4/3) * math.pi * radius**3
```

To test the function, we can use the following code:

```python
assert math.isclose(volume_sphere(10), 4188.790204786391, rel_tol=0.001)
```

This will check if the function returns a value that is within 0.1% of the expected value. If the function returns a value that is within 0.1% of the expected value, the test will pass. If not, it will raise an AssertionError. 