Here's the Python code to convert degrees to radians:

```python
import math

def radian_degree(degree):
    return math.radians(degree)
```

The `math.radians()` function takes an angle in degrees and returns its equivalent in radians. We can use this function to convert degrees to radians. The `assert` statement checks if the function returns the correct value for the given input. 