Here's the Python function to find the last position of an element in a sorted array:

```python
def last(arr, x):
    """
    This function takes a sorted array and an element as input and returns the last position of the element in the array.
    If the element is not found in the array, it returns -1.
    """
    n = len(arr)
    # Initialize the last position of the element to -1
    last_pos = -1
    # Loop through the array and find the last position of the element
    for i in range(n):
        if arr[n-1-i] == x:
            last_pos = n-1-i
    return last_pos
```

We can test the function with the given example:

```python
assert last([1,2,3],1) == 0
```

This should return `True` since the last position of 1 in the array [1,2,3] is 0. 