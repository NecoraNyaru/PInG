Here's a Python script that counts the number of indices where the two lists have the same values:

```python
def count_same_pair(list1, list2):
    count = 0
    for i in range(len(list1)):
        if list1[i] == list2[i]:
            count += 1
    return count
```

This function takes in two lists as arguments and iterates through them using a for loop. For each index i, it checks if the value at that index in both lists is the same. If they are the same, it increments the count variable. Finally, it returns the count of indices where the values are the same. In this case, the function would return 4 because the values at indices 1, 3, 4, and 5 are the same in both lists. 