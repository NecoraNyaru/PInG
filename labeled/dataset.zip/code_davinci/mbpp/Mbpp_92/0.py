Here's a Python function that checks whether a given number is undulating or not:

```python
def is_undulating(num):
    """
    This function takes a number as input and returns True if it is undulating, else False.
    An undulating number is a number where the digits alternate in their parity (odd or even).
    For example, 1212121 is an undulating number, but 12321 is not.
    """
    num_str = str(num)
    for i in range(len(num_str) - 1):
        if int(num_str[i]) % 2 == int(num_str[i+1]) % 2:
            return False
    return True
```

We first convert the number to a string to make it easier to work with. Then, we iterate through the digits of the number and check if the parity of each digit is the same as the parity of the next digit. If any two adjacent digits have the same parity, we return False. If we make it through the entire loop without returning False, the number is undulating and we return True. 