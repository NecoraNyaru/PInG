Here's the Python function to calculate the wind chill index:

```python
def wind_chill(wind_speed, temp):
    """
    Calculates the wind chill index based on the formula:
    wind_chill = 13.12 + 0.6215 * temp - 11.37 * wind_speed**0.16 + 0.3965 * temp**0.16
    """
    wind_chill = 13.12 + 0.6215 * temp - 11.37 * wind_speed**0.16 + 0.3965 * temp**0.16
    return round(wind_chill)
```

This function takes two arguments: `wind_speed` and `temp`. It calculates the wind chill index using the formula provided and returns the result rounded to the nearest integer.

To test the function, we can call it with the given values:

```python
assert wind_chill(120, 35) == 40
```

This will return `True` if the function returns `40` for the given inputs. 