Here's a Python function that implements the given problem:

```python
def get_max_sum(n):
    memo = {}
    def f(x):
        if x in memo:
            return memo[x]
        if x == 1:
            return 0
        elif x % 10 == 1:
            return 1
        elif x % 10 == 2:
            return 2
        elif x % 10 == 3:
            return 3
        elif x % 10 == 4:
            return 4
        elif x % 10 == 5:
            return 5
        elif x % 10 == 6:
            return 6
        elif x % 10 == 7:
            return 7
        elif x % 10 == 8:
            return 8
        elif x % 10 == 9:
            return 9
        else:
            return 0
        
    memo[1] = 0
    memo[2] = 2
    memo[3] = 3
    memo[4] = 4
    memo[5] = 5
    memo[6] = 6
    memo[7] = 7
    memo[8] = 8
    memo[9] = 9
    
    def helper(n):
        if n in memo:
            return memo[n]
        memo[n] = max(helper(n//2) + helper(n//3) + helper(n//4) + helper(n//5), n)
        return memo[n]
    
    return helper(n)
```

The function `get_max_sum(n)` takes an integer `n` as input and returns the maximum sum possible using the given equation. It uses memoization to store the values of `f(n/2)`, `f(n/3)`, `f(n/4)`, and `f(n/5)` in a dictionary `memo` to avoid recalculating them multiple times. The helper function `helper(n)` calculates the maximum sum recursively by finding the maximum of `f(n/2) + f(n/3) + f(n/4) + f(n/5)` and `n`. The base cases are when `n` is 1, 2, 3, 4, 5, 6, 7, 8, or 9, which are all defined in the `f` function. The function returns the maximum sum for the given input `n`.

To test the function, we can call `get_max_sum(60)` and check if it returns 106, which is the expected output. 