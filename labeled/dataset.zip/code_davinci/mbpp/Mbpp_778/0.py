Here's the Python function to pack consecutive duplicates of a given list elements into sublists:

```python
def pack_consecutive_duplicates(lst):
    result = []
    sublist = []
    for i in range(len(lst)):
        if i == 0 or lst[i] != lst[i-1]:
            sublist = [lst[i]]
            result.append(sublist)
        else:
            sublist.append(lst[i])
    return result
```

This function takes a list as input and returns a new list where consecutive duplicates of elements are packed into sublists. For example, if the input list is `[0, 0, 1, 2, 3, 4, 4, 5, 6, 6, 6, 7, 8, 9, 4, 4]`, the output will be `[[0, 0], [1], [2], [3], [4, 4], [5], [6, 6, 6], [7], [8], [9], [4, 4]]`.

Here's how it works:

1. We initialize an empty list `result` and an empty sublist `sublist`.
2. We loop through the input list `lst` using `for i in range(len(lst)`.
3. If the current element is different from the previous element (`lst[i] != lst[i-1]`), we append the current element to the sublist and append the sublist to the result list. We also initialize a new sublist for the next iteration.
4. If the current element is the same as the previous element (`lst[i] == lst[i-1]`), we append the current element to the sublist.
5. After the loop, we append the last sublist to the result list if it has any elements.
6. Finally, we return the result list.

Here's how we can test the function:

```python
lst = [0, 0, 1, 2, 3, 4, 4, 5, 6, 6, 6, 7, 8, 9, 4, 4]
print(pack_consecutive_duplicates(lst))
```

Output:
```
[[0, 0], [1], [2], [3], [4, 4], [5], [6, 6, 6], [7], [8], [9], [4, 4]]
``` 