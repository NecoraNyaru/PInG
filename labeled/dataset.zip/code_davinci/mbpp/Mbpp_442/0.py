Here's the Python script to find the ratio of positive numbers in an array of integers:

```python
def positive_count(arr):
    count = 0
    for num in arr:
        if num > 0:
            count += 1
    return count/len(arr)

assert positive_count([0, 1, 2, -1, -5, 6, 0, -3, -2, 3, 4, 6, 8]) == 0.54
```

Explanation:

We define a function `positive_count` that takes an array `arr` as input. We initialize a variable `count` to 0 and iterate through each element in the array. If the element is greater than 0, we increment the `count` variable by 1. After iterating through all the elements, we return the ratio of `count` to the length of the array. This gives us the ratio of positive numbers in the array. We use the `assert` statement to test the function with the given input and assert that it returns the expected output. 