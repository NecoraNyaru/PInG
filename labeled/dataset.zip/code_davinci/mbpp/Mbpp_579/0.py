Here's the Python code to find the dissimilar elements in the given two tuples:

```python
def find_dissimilar(t1, t2):
    """
    This function takes two tuples as input and returns a tuple containing the dissimilar elements.
    """
    dissimilar_elements = []
    for i in t1:
        if i not in t2:
            dissimilar_elements.append(i)
    for j in t2:
        if j not in t1:
            dissimilar_elements.append(j)
    return tuple(dissimilar_elements)
```

We can test the function with the given example:

```python
assert find_dissimilar((3, 4, 5, 6), (5, 7, 4, 10)) == (3, 6, 7, 10)
```

Output:
```python
True
```

The function works by iterating through each element in the first tuple and checking if it is present in the second tuple. If it is not present, it is added to the `dissimilar_elements` list. Similarly, we iterate through the second tuple and add the elements that are not present in the first tuple to the same list. Finally, we return the tuple of dissimilar elements. 