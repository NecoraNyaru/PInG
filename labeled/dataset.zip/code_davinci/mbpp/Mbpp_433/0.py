Here's the Python script to solve the problem:

```python
def check_greater(arr, num):
    for i in arr:
        if i > num:
            return False
    return True
```

This function takes in two arguments, an array `arr` and a number `num`. It then loops through each element in the array and checks if it is greater than `num`. If any element is greater than `num`, it returns `False`. If all elements in the array are less than `num`, it returns `True`. 