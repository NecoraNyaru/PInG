Here's the Python function to find the volume of a triangular prism:

```python
def find_Volume(base, height, thickness):
    return (base * height * thickness) / 2
```

This function takes in three parameters: `base`, `height`, and `thickness`. It calculates the volume of the triangular prism using the formula `base * height * thickness / 2` and returns the result.

To test the function, we can call it with the given values:

```python
assert find_Volume(10, 8, 6) == 240
```

This will return `True` if the function returns `240`, which is the expected output. 