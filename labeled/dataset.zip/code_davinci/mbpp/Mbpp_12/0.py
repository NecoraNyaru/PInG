Here's a possible solution:

def sort_matrix(matrix):
    # Calculate the sum of each row and store it in a list
    row_sums = [sum(row) for row in matrix]
    
    # Sort the matrix based on the row sums
    sorted_matrix = [row for _, row in sorted(zip(row_sums, matrix))]
    
    return sorted_matrix

# Test the function with the example input
assert sort_matrix([[1, 2, 3], [2, 4, 5], [1, 1, 1]]) == [[1, 1, 1], [1, 2, 3], [2, 4, 5]]

# Test the function with a different input
matrix = [[3, 2, 1], [4, 1, 5], [6, 2, 7], [1, 3, 5], [4, 2, 8]]
assert sort_matrix(matrix) == [[1, 3, 5], [4, 2, 8], [6, 2, 7], [3, 2, 1]]

# Test the function with an empty matrix
assert sort_matrix([]) == []

# Test the function with a matrix with only one row
assert sort_matrix([[1, 2, 3]) == [[1, 2, 3]

# Test the function with a matrix with only one column
assert sort_matrix([[1], [2], [3]]) == [[1], [2], [3]]

# Test the function with a matrix with negative numbers
assert sort_matrix([[1, -2, 3], [-1, 2, 4], [0, -3, 5]]) == [[-3, 0, 5], [-2, 2, 4], [1, -1, 3]

# Test the function with a matrix with repeated rows
assert sort_matrix([[1, 2, 3], [2, 4, 5], [1, 1, 1], [2, 4, 5]]) == [[1, 1, 1], [1, 2, 3], [2, 4, 5], [2, 4, 5]]

# Test the function with a matrix with repeated rows and negative numbers
assert sort_matrix([[1, -2, 3], [-1, 2, 4], [0, -3, 5], [-1, 2, 4]]) == [[-3, 0, 5], [-2, 2, 4], [1, -1, 3], [-1, 2, 4] 