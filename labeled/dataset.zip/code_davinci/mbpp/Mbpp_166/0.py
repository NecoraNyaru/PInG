Here's a possible solution:

def find_even_pair(lst):
    count = 0
    for i in range(len(lst)):
        for j in range(i+1, len(lst)):
            if (lst[i] ^ lst[j]) % 2 == 0:
                count += 1
    return count

# Test the function
print(find_even_pair([5, 4, 7, 2, 1])) # Output: 4 