Here's a Python function that takes a list as input and returns all possible combinations of its elements:

```python
def combinations_list(lst):
    if len(lst) == 0:
        return [[]]
    else:
        rest_combinations = combinations_list(lst[1:])
        return [ [lst[0]] + combination for combination in rest_combinations] + rest_combinations
```

This function works by recursively calling itself with the list excluding the first element, and then adding the first element to each of the returned combinations. The base case is when the list is empty, in which case it returns a list containing an empty list. The function returns a list of lists, where each sublist represents a combination of elements in the original list. 