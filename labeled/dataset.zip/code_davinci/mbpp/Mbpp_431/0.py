Here's the Python code for the function:

```python
def common_element(list1, list2):
    """
    This function takes two lists as input and returns True if they have at least one common element, False otherwise.
    """
    for i in list1:
        for j in list2:
            if i == j:
                return True
    return False
```

We can test the function with the given example:

```python
assert common_element([1,2,3,4,5], [5,6,7,8,9]) == True
```

Output:
```python
True
```

The function works by iterating through each element in the first list and checking if it exists in the second list. If it finds a match, it returns True. If it iterates through the entire first list without finding a match, it returns False. 