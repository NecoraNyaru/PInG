Here's a Python function that takes an array and finds the maximum sum of a bitonic subsequence:

```python
def max_sum(arr):
    n = len(arr)
    if n == 1:
        return arr[0]
    
    incl = arr[:]
    # initialize the incl array with the first element
    incl[1] = max(arr[0], arr[1])
    
    # initialize the excl array with the first element
    excl = [0] * n
    excl[0] = arr[0]
    
    # initialize the maximum sum of a bitonic subsequence
    max_sum = 0
    
    # loop through the array from index 2 to n-1
    for i in range(2, n):
        incl[i] = max(incl[i-1] + arr[i], arr[i])
        excl[i] = max(excl[i-1], incl[i-1])
        
        # update the maximum sum of a bitonic subsequence
        max_sum = max(max_sum, excl[i] + incl[i])
    
    return max_sum
```

Explanation:

We first check if the length of the array is 1, in which case the maximum sum of a bitonic subsequence is simply the element itself. Otherwise, we initialize two arrays, `incl` and `excl`, with the first element of the array. We then loop through the array from index 2 to n-1 and update the `incl` and `excl` arrays accordingly. The `incl` array keeps track of the maximum sum of a bitonic subsequence that ends at each index, while the `excl` array keeps track of the maximum sum of a bitonic subsequence that ends before the current index. We update the `incl` array by taking the maximum of the current element and the sum of the previous element and the current element. We update the `excl` array by taking the maximum of the previous element and the current element. Finally, we return the maximum of the sum of the `excl` and `incl` arrays.

The `incl` array keeps track of the maximum sum of a bitonic subsequence that ends at each index, while the `excl` array keeps track of the maximum sum of a bitonic subsequence that ends before the current index. We update the `incl` array by taking the maximum of the current element and the sum of the previous element and the current element. We update the `excl` array by taking the maximum of the previous element and the current element. Finally, we return the maximum of the sum of the `excl` and `incl` arrays. 