Here's the Python function to convert a snake case string to camel case string:

```python
def snake_to_camel(snake_str):
    words = snake_str.split('_')
    return words[0] + ''.join(word.title() for word in words[1:])
```

Explanation:

- We first split the snake case string into a list of words using the `split()` method with `_` as the separator.
- We then capitalize the first letter of each word in the list using the `title()` method and join them back together using an empty string `''`.
- We return the resultant string as the camel case string.

Example:

```python
>>> snake_to_camel('python_program')
'PythonProgram'
``` 