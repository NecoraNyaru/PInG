Here's the Python function to find the cube sum of first n even natural numbers:

```python
def cube_Sum(n):
    sum = 0
    for i in range(2, n*2, 2):
        sum += i**3
    return sum
```

Explanation:
- We initialize a variable `sum` to 0.
- We use a for loop to iterate from 2 to `n*2` (since we only need even numbers).
- For each even number `i`, we add its cube to the `sum` variable.
- Finally, we return the `sum` variable.

Example:
```python
>>> cube_Sum(2)
72
```

The cube of 2 is 8, and the cube of 4 is 64. Adding these two numbers gives us 72. 