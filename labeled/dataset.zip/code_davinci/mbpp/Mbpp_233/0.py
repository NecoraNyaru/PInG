Here's a Python function to find the lateral surface area of a cylinder:

```python
import math

def lateralsurface_cylinder(radius, height):
    return 2 * math.pi * radius * height + 2 * math.pi * radius ** 2
```

This function takes in two parameters, `radius` and `height`, and returns the lateral surface area of a cylinder using the formula `2 * pi * r * h + 2 * pi * r^2`. The `math.isclose` function is used to check if the result is close to the expected value with a relative tolerance of 0.001. If the result is not close to the expected value, the function will return `False`.

```python
assert math.isclose(lateralsurface_cylinder(10, 5), 314.1500000000003, rel_tol=0.001)
```

This assertion will pass if the function returns a value that is within 0.001 of 314.15. If you want to test the function with different values, you can change the arguments to the function. For example:

```python
assert math.isclose(lateralsurface_cylinder(5, 10), 314.1500000000003, rel_tol=0.001)
```

This will test the function with a cylinder with a radius of 5 and a height of 10. 