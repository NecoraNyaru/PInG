Here's the Python script for the given problem:

```python
def text_match_wordz(text):
    if 'z' in text:
        return True
    else:
        return False
```

This function takes a string as input and checks if the word 'z' is present in it. If it is present, it returns True, otherwise, it returns False. We can test this function by calling it with the string 'pythonz' as an argument:

```python
print(text_match_wordz("pythonz")) # Output: True
```

If we call it with a string that doesn't contain 'z', it will return False:

```python
print(text_match_wordz("python")) # Output: False
``` 