Here's the Python script for the given problem:

```python
def text_starta_endb(string):
    if string.startswith('a') and string.endswith('b'):
        return True
    else:
        return False
```

The `startswith()` method checks if the string starts with 'a' and the `endswith()` method checks if the string ends with 'b'. If both conditions are true, the function returns `True`, otherwise it returns `False`. 