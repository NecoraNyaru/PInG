Here's the Python function to find the difference between the sum of cubes of the first n natural numbers and the sum of the first n natural numbers:

```python
def difference(n):
    sum_of_cubes = sum([i**3 for i in range(1, n+1)])
    sum_of_numbers = sum(range(1, n+1))
    return sum_of_cubes - sum_of_numbers
```

This function takes an integer `n` as input and returns the difference between the sum of cubes of the first `n` natural numbers and the sum of the first `n` natural numbers. We use list comprehension to calculate the sum of cubes of the first `n` natural numbers and the built-in `sum()` function to calculate the sum of the first `n` natural numbers. The difference between the two is then returned. 

For example, `difference(3)` will return `30`, since the sum of cubes of the first three natural numbers is `1^3 + 2^3 + 3^3 = 1 + 8 + 27 = 30`, and the sum of the first three natural numbers is `1 + 2 + 3 = 6`. Therefore, the difference is `30 - 6 = 24`. 