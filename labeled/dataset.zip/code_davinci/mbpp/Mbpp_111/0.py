Here's a possible solution:

def common_in_nested_lists(lists):
    common = set()
    for lst in lists:
        for num in lst:
            if all(num in lst2 for lst2 in lists):
                common.add(num)
    return common

# Test the function
assert set(common_in_nested_lists([[12, 18, 23, 25, 45], [7, 12, 18, 24, 28], [1, 5, 8, 12, 15, 16, 18]]) == set([18, 12])

# Output: True 