Here's the Python script to check whether all dictionaries in a list are empty or not:

```python
def empty_dict(lst):
    for i in lst:
        if i:
            return False
    return True
```

This function takes a list of dictionaries as input and returns True if all the dictionaries in the list are empty, else it returns False. It does this by iterating over each dictionary in the list and checking if it is empty using the `if i:` statement. If any dictionary is not empty, the function returns False, otherwise it returns True. 