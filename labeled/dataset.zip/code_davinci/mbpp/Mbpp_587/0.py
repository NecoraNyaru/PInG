Here's the Python code to convert a list to a tuple:

```python
def list_tuple(lst):
    return tuple(lst)
```

This function takes a list as an argument and returns a tuple with the same elements as the list. The `tuple()` function is used to convert the list to a tuple. 