Here's a Python function that counts the number of inversions in an array using merge sort algorithm:

```python
def merge_sort(arr):
    if len(arr) <= 1:
        return arr, 0
    
    mid = len(arr) // 2
    left, inv_count = merge_sort(arr[:mid])
    right, inv_count = merge_sort(arr[mid:])
    
    return merge(left, right, inv_count)
    
def merge(left, right, inv_count):
    result = []
    i = j = 0
    
    while i < len(left) and j < len(right):
        if left[i] < right[j]:
            result.append(left[i])
            i += 1
        else:
            result.append(right[j])
            inv_count += len(left) - i
            j += 1
    
    result += left[i:]
    result += right[j:]
    
    return result, inv_count

def get_Inv_Count(arr):
    sorted_arr, inv_count = merge_sort(arr)
    return inv_count
```

The `merge_sort` function recursively sorts the array and returns the sorted array and the count of inversions. The `merge` function merges two sorted subarrays and counts the number of inversions while merging them. The `get_Inv_Count` function calls `merge_sort` on the input array and returns the count of inversions. 

Example:

```python
>>> get_Inv_Count([1,20,6,4,5])
5
``` 