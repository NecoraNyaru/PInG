Here's the Python function to find the highest power of 2 that is less than or equal to n:

```python
def highest_Power_of_2(n):
    power = 1
    while (2**power) <= n:
        power += 1
    return 2**(power-1)
```

Explanation:

We can use the binary representation of the number to find the highest power of 2 that is less than or equal to n. For example, if n is 10, the binary representation of n is 1010. The highest power of 2 that is less than or equal to n is 8, which is 2^3. We can use a while loop to keep incrementing the power until 2^power is greater than n. Then, we return 2^(power-1) as it is the highest power of 2 that is less than or equal to n. 