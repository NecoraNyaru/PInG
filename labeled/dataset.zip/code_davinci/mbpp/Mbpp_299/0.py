Here's a possible solution:

def max_aggregate(lst):
    # Create a dictionary to store the scores for each student
    scores = {}
    for name, score in lst:
        if name in scores:
            scores[name] += score
        else:
            scores[name] = score
    
    # Find the maximum score
    max_score = max(scores.values())
    
    # Find the student(s) with the maximum score
    max_students = [name for name, score in scores.items() if score == max_score]
    
    # Return the name of the student(s) with the maximum score and their total score
    return max_students, max_score

# Test the function with the given example
assert max_aggregate([('Juan Whelan',90),('Sabah Colley',88),('Peter Nichols',7),('Juan Whelan',122),('Sabah Colley',84)]) == ('Juan Whelan', 212) 