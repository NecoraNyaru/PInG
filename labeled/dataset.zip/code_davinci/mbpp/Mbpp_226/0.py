Here's the Python function to remove the characters which have odd index values of a given string:

```python
def odd_values_string(string):
    result = ""
    for i in range(len(string)):
        if i % 2 == 0:
            result += string[i]
    return result
```

Explanation:
- We initialize an empty string `result` to store the characters with even index values.
- We loop through the string using a `for` loop and check if the index value is even or odd using the modulo operator `%`.
- If the index value is even, we add the character to the `result` string.
- Finally, we return the `result` string which contains only the characters with even index values. 