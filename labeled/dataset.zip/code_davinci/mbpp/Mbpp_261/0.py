Here's the Python script for the given problem:

```python
def division_elements(tup1, tup2):
    """
    This function takes in two tuples and performs mathematical division operation element-wise across the given tuples.
    """
    result = []
    for i in range(len(tup1)):
        result.append(tup1[i] / tup2[i])
    return tuple(result)

# Testing the function
print(division_elements((10, 4, 6, 9), (5, 2, 3, 3))) # Output: (2.0, 2.0, 3.0, 3.0)
```

Explanation:

We define a function `division_elements` that takes in two tuples `tup1` and `tup2`. We initialize an empty list `result` to store the result of the division operation. We then loop through the length of `tup1` using a `for` loop and append the division of `tup1[i]` and `tup2[i]` to the `result` list. Finally, we convert the `result` list to a tuple and return it. The `assert` statement is used to test the function with the given input and output. 