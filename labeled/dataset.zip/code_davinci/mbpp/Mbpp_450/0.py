Here's the Python script to extract specified size of strings from a given list of string values:

```python
def extract_string(lst, size):
    return [s for s in lst if len(s) >= size]
```

This function takes two arguments: `lst` is the list of strings and `size` is the size of the strings to be extracted. It uses a list comprehension to iterate over each string in the list and checks if the length of the string is greater than or equal to the specified size. If the length of the string is greater than or equal to the size, it is added to a new list and returned. The function returns the new list of strings that meet the specified size criteria. In the example provided, `extract_string(['Python', 'list', 'exercises', 'practice', 'solution'], 8)` would return `['practice', 'solution']`. 