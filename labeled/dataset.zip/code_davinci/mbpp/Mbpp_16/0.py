Here's the Python function that checks if a string contains sequences of lowercase letters joined with an underscore:

```python
def text_lowercase_underscore(string):
    """
    This function checks if a string contains sequences of lowercase letters joined with an underscore.
    """
    # Split the string into words using underscore as the delimiter
    words = string.split('_')
    
    # Check if all words are lowercase
    for word in words:
        if not word.islower():
            return False
    
    # If all words are lowercase, return True
    return True
```

We first split the input string into words using the underscore as the delimiter. Then, we iterate over each word and check if it is lowercase using the `islower()` method. If any word is not lowercase, we return False. If all words are lowercase, we return True. 