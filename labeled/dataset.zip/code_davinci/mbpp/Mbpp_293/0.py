Here's the Python script to find the third side of a right angled triangle:

```python
import math

def otherside_rightangle(opposite, adjacent):
    hypotenuse = math.sqrt(opposite**2 + adjacent**2)
    return round(hypotenuse, 2)

print(otherside_rightangle(7,8)) # Output: 10.63
```

Explanation:

We use the Pythagorean theorem to find the third side of a right angled triangle. The formula for finding the hypotenuse of a right angled triangle is:

h = sqrt(opposite^2 + adjacent^2)

where h is the hypotenuse, opposite is the length of the side opposite the right angle, and adjacent is the length of the side adjacent to the right angle. We use the math module to calculate the square root of the sum of the squares of the opposite and adjacent sides. We then round the result to two decimal places using the round() function. 