Here's a Python function to find the nth tetrahedral number:

```python
def tetrahedral_number(n):
    """
    Returns the nth tetrahedral number.
    """
    return (n * (n + 1) * (n + 2)) // 2
```

This function uses the formula for the nth tetrahedral number, which is (n * (n + 1) * (n + 2)) // 2. The // operator is used to perform integer division, which ensures that the result is an integer.

To test the function, we can call it with the value 5 and check if it returns 35:

```python
assert tetrahedral_number(5) == 35
```

This should return True, indicating that the function is working correctly. 