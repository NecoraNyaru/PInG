Here's the Python script for the given problem:

```python
def substract_elements(tup1, tup2):
    """
    This function takes in two tuples and subtracts the elements of the first tuple by the elements of the second tuple with the same index.
    """
    result = []
    for i in range(len(tup1)):
        result.append(tup1[i] - tup2[i])
    return tuple(result)

# Testing the function
print(substract_elements((10, 4, 5), (2, 5, 18))) # Output: (8, -1, -13)
```

Explanation:

We define a function `substract_elements` that takes in two tuples `tup1` and `tup2`. We initialize an empty list `result` to store the result. We then loop through the indices of `tup1` using `range(len(tup1))` and subtract the corresponding elements of `tup2` from the elements of `tup1` and append the result to `result`. Finally, we convert `result` to a tuple and return it. 