Here's the Python function that takes in an integer n and returns the sum of the squares of the first n odd natural numbers:

```python
def square_Sum(n):
    sum = 0
    for i in range(1, n*2, 2):
        sum += i**2
    return sum
```

Explanation:
- We initialize a variable `sum` to 0 to keep track of the sum of squares of odd numbers.
- We use a `for` loop to iterate through the odd numbers from 1 to `n*2` (since the last odd number is `n*2-1`).
- For each odd number `i`, we add its square to the `sum` variable.
- Finally, we return the `sum` variable.

Example:
```python
>>> square_Sum(2)
10
```

This function will return 10 because the squares of the first two odd numbers are 1 and 9, which add up to 10. 