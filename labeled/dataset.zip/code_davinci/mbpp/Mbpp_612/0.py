Here's the Python function that takes a list of lists and returns a list of two lists where the first list has the first element of each sublist and the second one has the second element of each sublist:

```python
def merge(lst):
    return [[lst[i][0] for i in range(len(lst))], [lst[i][1] for i in range(len(lst))]]
```

This function uses list comprehension to iterate over each sublist in the input list and extract the first and second element of each sublist and append them to two separate lists. Finally, it returns a list containing these two lists as elements. 