Here's the Python code for the function:

```python
def sum_list(a, b):
    """
    This function takes two lists a and b as input and returns a new list that contains the sum of corresponding elements of a and b.
    """
    assert len(a) == len(b), "Both lists should have the same length"
    result = []
    for i in range(len(a)):
        result.append(a[i] + b[i])
    return result
```

We can test the function with the given example:

```python
assert sum_list([10,20,30],[15,25,35]) == [25,45,65]
```

This will return True since the function returns the expected output. 