Here's the Python function to count the number of positive numbers in a list:

```python
def pos_count(lst):
    count = 0
    for num in lst:
        if num > 0:
            count += 1
    return count
```

This function takes a list as an argument and initializes a count variable to 0. It then iterates through each element in the list and checks if it is greater than 0. If it is, it increments the count variable. Finally, it returns the count variable which represents the number of positive numbers in the list. 

To test the function, you can call it with the example list provided in the problem statement:

```python
print(pos_count([1,-2,3,-4])) # Output: 2
```

This will return 2 because there are two positive numbers in the list, 1 and 3. 