Here's the Python script to check if each element of the second tuple is smaller than its corresponding element in the first tuple:

```python
def check_smaller(tup1, tup2):
    for i in range(len(tup1)):
        if tup1[i] > tup2[i]:
            return False
    return True
```

This function takes two tuples as input and compares each element of the second tuple with its corresponding element in the first tuple. If any element in the second tuple is greater than its corresponding element in the first tuple, it returns False. If all elements in the second tuple are smaller than their corresponding elements in the first tuple, it returns True. 