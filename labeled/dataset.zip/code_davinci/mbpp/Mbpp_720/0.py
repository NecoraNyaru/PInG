Here's the Python script to add a dictionary to a tuple:

```python
def add_dict_to_tuple(tup, dict_val):
    return tup + (dict_val,)
```

This function takes in two arguments: a tuple `tup` and a dictionary `dict_val`. It returns a new tuple that contains the original tuple and the dictionary as the last element. The `+` operator is used to concatenate the tuple and the dictionary into a new tuple. The `,` at the end of the dictionary is used to convert the dictionary into a tuple. The `()` is used to create a tuple with one element, which is the dictionary. 