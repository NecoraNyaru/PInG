Here's a Python function that sorts a list of elements using the Comb Sort algorithm:

```python
def comb_sort(lst):
    n = len(lst)
    shrink = 1.3
    sorted = False
    while not sorted:
        shrink = shrink * 0.9
        sorted = True
        for i in range(1, n):
            if lst[i - 1] > lst[i]:
                lst[i], lst[i - 1] = lst[i - 1], lst[i]
                sorted = False
        for i in range(0, n - 1):
            if abs(lst[i] - lst[i + 1]) > shrink:
                sorted = False
                j = i - 1
                while j >= 0 and lst[j] > lst[i]:
                    lst[j + 1], lst[j] = lst[j], lst[j + 1]
                    j -= 1
                if j != i - 1:
                    sorted = False
    return lst
```

This function uses the Comb Sort algorithm to sort the list. The algorithm is similar to the Bubble Sort algorithm, but it has a shrink factor that reduces the distance between swaps. It works by comparing adjacent elements and swapping them if they are out of order, and then comparing non-adjacent elements with a smaller gap until the list is sorted. The shrink factor is reduced each time the list is sorted, and the loop continues until the list is sorted or the shrink factor becomes too small.

To test the function, you can call it with the list [5, 15, 37, 25, 79] and it should return [5, 15, 25, 37, 79]. 