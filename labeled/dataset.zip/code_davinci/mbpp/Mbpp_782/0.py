Here's a Python function that finds the sum of all odd length subarrays of a given list:

```python
def odd_length_sum(arr):
    n = len(arr)
    total_sum = 0
    for i in range(n):
        for j in range(i+1, n):
            for k in range(j+1, n):
                if k-j+1 % 2 != 0:
                    total_sum += sum(arr[i:k+1])
    return total_sum
```

This function takes a list `arr` as input and iterates through all possible subarrays of odd length using three nested loops. For each subarray, it checks if the length is odd by checking if the difference between the end index and start index is odd. If it is, it adds the sum of the subarray to the `total_sum` variable. Finally, it returns the total sum of all odd length subarrays.

For example, if we call `odd_length_sum([1,2,4])`, it will iterate through the following subarrays:

- [1,2,4]
- [2,4]
- [4]

And the sum of these subarrays is 1+2+4+4=9.

Therefore, the function returns 9. 