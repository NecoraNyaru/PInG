Here's the Python script to extract the rear index element of each string in the given tuple:

```python
def extract_rear(lst):
    return [s[-1] for s in lst]
```

This function takes a tuple `lst` as input and returns a new list containing the last character of each string in the tuple. The `[-1]` index is used to access the last character of each string in the list. The `for` loop iterates over each string in the tuple and appends the last character to a new list using a list comprehension. The resulting list is then returned. 