Here's the Python function to convert a given string to uppercase:

```python
def is_upper(string):
    return string.upper()
```

This function takes a string as an input and returns the uppercase version of the string. For example, if you call `is_upper("person")`, it will return `"PERSON"`. 