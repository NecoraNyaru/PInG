Here's the Python code to convert a string to a list of strings split on the space character:

```python
def string_to_list(string):
    return string.split()
```

This function takes a string as input and returns a list of strings where each string is a word in the input string. The `split()` method is used to split the string into a list of words based on the space character. The default behavior of `split()` is to split the string at every whitespace character, including spaces, tabs, and newlines. 