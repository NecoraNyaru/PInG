Here's the Python function to check whether the given two integers have opposite sign or not:

```python
def opposite_Signs(a, b):
    if a*b < 0:
        return True
    else:
        return False
```

Explanation:

The function takes two integers as input parameters `a` and `b`. If the product of `a` and `b` is less than zero, then they have opposite signs. If the product of `a` and `b` is greater than or equal to zero, then they have the same sign. Therefore, we can check if the product of `a` and `b` is less than zero to determine if they have opposite signs. If the product is less than zero, then we return `True`, else we return `False`. 