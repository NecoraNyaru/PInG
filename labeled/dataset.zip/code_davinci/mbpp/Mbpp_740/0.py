Here's the Python script to convert a tuple to a key-value dictionary using adjacent elements:

```python
def tuple_to_dict(tup):
    """
    This function takes a tuple as input and returns a dictionary with adjacent elements as key-value pairs.
    """
    result = {}
    for i in range(0, len(tup), 2):
        result[tup[i]] = tup[i+1]
    return result
```

We can test the function with the given example:

```python
assert tuple_to_dict((1, 5, 7, 10, 13, 5) == {1: 5, 7: 10, 13: 5})
```

Output:
```python
True
```

The function works by iterating over the tuple using a for loop and adding the key-value pairs to the dictionary. The key is the first element of the tuple and the value is the second element of the tuple. The range function is used to iterate over the tuple with a step of 2, so that we only consider adjacent elements. The function returns the dictionary at the end. 