Here's the Python script to count lists within a list:

```python
def count_lists(lst):
    count_dict = {}
    for sublist in lst:
        sublist_tuple = tuple(sublist)
        if sublist_tuple in count_dict:
            count_dict[sublist_tuple] += 1
        else:
            count_dict[sublist_tuple] = 1
    return count_dict
```

This function takes a list `lst` as input and creates an empty dictionary `count_dict`. It then iterates through each sublist in `lst` and converts it to a tuple using the `tuple()` function. If the tuple already exists in `count_dict`, it increments its value by 1, otherwise it adds the tuple to the dictionary with a value of 1. Finally, it returns the `count_dict` dictionary. 