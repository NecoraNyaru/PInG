Here's the Python function to find the sum of numbers in a list within a range specified by two indices:

```python
def sum_range_list(lst, start, end):
    """
    This function takes a list of numbers and two indices as input and returns the sum of numbers between the indices.
    """
    # Initialize the sum variable to 0
    total = 0
    # Loop through the list from start to end index
    for i in range(start, end+1):
        # Add the current element to the total
        total += lst[i]
    # Return the total sum
    return total
```

You can call this function with the given list and indices as arguments:

```python
print(sum_range_list([2,1,5,6,8,3,4,9,10,11,8,12], 8, 10)) # Output: 29
```

This function works by looping through the list from the start index to the end index and adding each element to a variable called `total`. The `range()` function is used to generate a sequence of indices from the start index to the end index (inclusive) and then the `+=` operator is used to add each element to the `total` variable. Finally, the function returns the total sum. 