Here's the Python function to check if the given tuples contain the k or not:

```python
def check_K(tup, k):
    if k in tup:
        return True
    else:
        return False
```

This function takes two arguments, the first argument is the tuple and the second argument is the value to be checked. It uses the `in` keyword to check if the value `k` is present in the tuple `tup`. If it is present, it returns `True`, otherwise, it returns `False`.

Example:

```python
assert check_K((10, 4, 5, 6, 8), 6) == True
```

Output:

```python
True
``` 