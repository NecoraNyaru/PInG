Here's the Python function to locate the left insertion point for a specified value in a sorted list:

```python
def left_insertion(arr, val):
    """
    This function takes a sorted list and a value as input and returns the left insertion point of the value in the list.
    """
    left = 0
    right = len(arr) - 1
    while left <= right:
        mid = (left + right) // 2
        if arr[mid] == val:
            return mid
        elif arr[mid] < val:
            left = mid + 1
        else:
            right = mid - 1
    return left
```

Explanation:

The function takes a sorted list `arr` and a value `val` as input. It initializes two pointers `left` and `right` to the first and last indices of the list, respectively. It then enters a loop that continues until `left` is greater than `right`. In each iteration, it calculates the middle index `mid` of the list and checks if the value at `mid` is equal to `val`. If it is, the function returns `mid`. If the value at `mid` is less than `val`, it updates `left` to `mid + 1` to search the right half of the list. If the value at `mid` is greater than `val`, it updates `right` to `mid - 1` to search the left half of the list. The loop continues until `left` is greater than `right`, at which point the function returns `left`. This is because the left insertion point is the index where `val` should be inserted to maintain the sorted order of the list. 