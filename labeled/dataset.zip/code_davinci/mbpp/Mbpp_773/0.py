Here's a Python function that finds the occurrence and position of a substring within a string:

```python
def occurance_substring(string, substring):
    if substring in string:
        return (substring, string.index(substring), string.rindex(substring))
    else:
        return None
```

This function takes two arguments: `string` and `substring`. It first checks if the `substring` is present in the `string`. If it is, it returns a tuple containing the `substring`, the index of the first occurrence of the substring in the string, and the index of the last occurrence of the substring in the string. If the `substring` is not present in the `string`, it returns `None`.

For example:

```python
>>> occurance_substring('python programming, python language', 'python')
('python', 0, 20)
```

In this case, the `substring` 'python' is present in the `string` twice, and the first occurrence starts at index 0 and the last occurrence starts at index 20. 