Here's a Python function that takes two binary strings as input and returns the minimum number of swaps required to convert the first string to the second string:

```python
def min_swaps(binary1, binary2):
    # Convert the binary strings to lists of integers
    binary1_list = list(map(int, binary1))
    binary2_list = list(map(int, binary2))

    # Initialize a dictionary to store the frequency of each digit in binary1
    freq = {}
    for digit in binary1_list:
        freq[digit] = freq.get(digit, 0) + 1

    # Initialize a list to store the digits of binary2 in the order they appear in binary1
    binary2_order = []

    # Iterate through binary2 and count the frequency of each digit
    for digit in binary2_list:
        freq[digit] = freq.get(digit, 0) - 1
        if freq[digit] == 0:
            del freq[digit]
        elif digit not in binary2_order:
            binary2_order.append(digit)

    # Initialize a counter for the number of swaps
    swaps = 0

    # Iterate through the remaining digits in freq and add them to binary2_order
    for digit, count in freq.items():
        for i in range(count):
            binary2_order.append(digit)

    # Iterate through binary2_order and count the number of swaps required to convert binary2 to binary1
    for i in range(len(binary2_order)):
        if binary2_order[i] != binary1_list[i]:
            swaps += 1

    return swaps
```

This function works by first converting the binary strings to lists of integers and then using a dictionary to store the frequency of each digit in binary1. It then iterates through binary2, counting the frequency of each digit and adding the digits that are not already in binary2_order to the list. Finally, it iterates through binary2_order and counts the number of swaps required to convert it to binary1 by comparing each digit to its corresponding position in binary1. The function returns the total number of swaps required. 