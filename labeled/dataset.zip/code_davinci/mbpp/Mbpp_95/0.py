Here's the Python function to find the length of the smallest list in a list of lists:

```python
def Find_Min_Length(lst):
    min_length = len(lst[0])
    for i in lst:
        if len(i) < min_length:
            min_length = len(i)
    return min_length
```

This function takes a list of lists as input and initializes the `min_length` variable to the length of the first list in the list. It then iterates through each list in the input list and checks if the length of the current list is less than the current `min_length`. If it is, it updates `min_length` to be the length of the current list. Finally, it returns `min_length` which will be the length of the smallest list in the input list. 