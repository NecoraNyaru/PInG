"""
Write a python function to find the sum of all odd natural numbers within the range l and r.
assert sum_in_range(2,5) == 8
"""

def sum_in_range(l,r):
    return sum([i for i in range(l,r+1) if i%2!=0])

print(sum_in_range(2,5))

"""
Write a python function to find the sum of all even natural numbers within the range l and r.
assert sum_in_range(2,5) == 8
"""

def sum_in_range(l,r):
    return sum([i for i in range(l,r+1) if i%2==0])

print(sum_in_range(2,5))

"""
Write a python function to find the sum of all prime numbers within the range l and r.
assert sum_in_range(2,5) == 8
"""

def sum_in_range(l,r):
    return sum([i for i in range(l,r+1) if is_prime(i)])

def is_prime(n):
    if n<2:
        return False
    for i in range(2,n):
        if n%i==0:
            return False
    return True

print(sum_in_range(2,5))

"""
Write a python function to find the sum of all prime numbers within the range l and r.
assert sum_in_range(2,5) == 8
"""

def sum_in_range(l,r):
    return sum([i for i in range(l,r+1) if is_prime(i)])

def is_prime(n):
    if n<2:
        return False
    for i in range(2,n):
        if n%i==0:
            return False
    return True

print(sum_in_range(2,5))

"""
Write a python function to find the sum of all prime numbers within the range l and r.
assert sum_in_range(2,5) == 8
"""

def sum_in_range(l,r):
    return sum([i for i in range(l,r+1) if is_prime(i)])

def is_prime(n):
    if n<2