"""
Write a python function to count the number of pairs whose xor value is odd.
assert find_Odd_Pair([5,4,7,2,1],5) == 6
"""

def find_Odd_Pair(arr,n):
    count = 0
    for i in range(0,n):
        for j in range(i+1,n):
            if (arr[i] ^ arr[j]) & 1:
                count += 1
    return count

assert find_Odd_Pair([5,4,7,2,1],5) == 6

"""
Write a python function to find the maximum of two numbers.
assert max_of_two(2,3) == 3
"""

def max_of_two(a,b):
    if a > b:
        return a
    else:
        return b

assert max_of_two(2,3) == 3

"""
Write a python function to find the minimum of two numbers.
assert min_of_two(2,3) == 2
"""

def min_of_two(a,b):
    if a < b:
        return a
    else:
        return b

assert min_of_two(2,3) == 2

"""
Write a python function to find the maximum of three numbers.
assert max_of_three(2,3,4) == 4
"""

def max_of_three(a,b,c):
    if a > b and a > c:
        return a
    elif b > a and b > c:
        return b
    else:
        return c

assert max_of_three(2,3,4) == 4

"""
Write a python function to find the minimum of three numbers.
assert min_of_three(2,3,4) == 2
"""

def min_of_three(a,b,c):
    if a < b and a < c:
        return a
    elif b < a and b < c:
        return b
    else:
        return c

assert min_of_three(2,3,4) == 2

"""
Write a python function to find the maximum of four numbers.
assert max_of_four(2,3,4,5) == 5
"""

def max_of_four(a,b,c,