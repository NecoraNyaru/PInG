"""
Write a function to find the second smallest number in a list.
assert second_smallest([1, 2, -8, -2, 0, -2])==-2
"""

def second_smallest(lst):
    lst.sort()
    return lst[1]

print(second_smallest([1, 2, -8, -2, 0, -2]))

"""
Write a function to find the second largest number in a list.
assert second_largest([1, 2, -8, -2, 0, -2])==0
"""

def second_largest(lst):
    lst.sort()
    return lst[-2]

print(second_largest([1, 2, -8, -2, 0, -2]))

"""
Write a function to find the second largest number in a list.
assert second_largest([1, 2, -8, -2, 0, -2])==0
"""

def second_largest(lst):
    lst.sort()
    return lst[-2]

print(second_largest([1, 2, -8, -2, 0, -2]))

"""
Write a function to find the second largest number in a list.
assert second_largest([1, 2, -8, -2, 0, -2])==0
"""

def second_largest(lst):
    lst.sort()
    return lst[-2]

print(second_largest([1, 2, -8, -2, 0, -2]))

"""
Write a function to find the second largest number in a list.
assert second_largest([1, 2, -8, -2, 0, -2])==0
"""

def second_largest(lst):
    lst.sort()
    return lst[-2]

print(second_largest([1, 2, -8, -2, 0, -2]))

"""
Write a function to find the second largest number in a list.
assert second_largest([1, 2, -8, -2, 0, -2])==0
"""

def second_largest(lst):
    lst.sort()
    return lst[-2]

print(second_largest([1, 2, -8, -2, 0, -2]))

