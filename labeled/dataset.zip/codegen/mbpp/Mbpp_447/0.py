"""
Write a function to find cubes of individual elements in a list.
assert cube_nums([1, 2, 3, 4, 5, 6, 7, 8, 9, 10])==[1, 8, 27, 64, 125, 216, 343, 512, 729, 1000]
"""

def cube_nums(nums):
    return [i**3 for i in nums]

print(cube_nums([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]))

"""
Write a function to find the mean, median, and mode of a list of numbers.
assert mean([1, 2, 3, 4, 5, 6, 7, 8, 9, 10])==5.5
assert median([1, 2, 3, 4, 5, 6, 7, 8, 9, 10])==5
assert mode([1, 2, 3, 4, 5, 6, 7, 8, 9, 10])==[1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
"""

def mean(nums):
    return sum(nums)/len(nums)

def median(nums):
    nums.sort()
    if len(nums)%2==0:
        return (nums[len(nums)//2]+nums[len(nums)//2-1])/2
    else:
        return nums[len(nums)//2]

def mode(nums):
    nums_dict = {}
    for i in nums:
        if i in nums_dict:
            nums_dict[i]+=1
        else:
            nums_dict[i]=1
    max_value = max(nums_dict.values())
    return [i for i in nums_dict if nums_dict[i]==max_value]

print(mean([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]))
print(median([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]))
print(mode([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]))

"""
Write a function to find the mean, median, and mode of a list of numbers.
assert mean([1, 2, 3, 4, 5, 6, 7, 8, 9, 10])==5.5
assert median([1, 2, 3