"""
Write a python function to find the first digit of a given number.
assert first_Digit(123) == 1
"""

def first_Digit(num):
    return int(str(num)[0])

print(first_Digit(123))

"""
Write a python function to find the last digit of a given number.
assert last_Digit(123) == 3
"""

def last_Digit(num):
    return int(str(num)[-1])

print(last_Digit(123))

"""
Write a python function to find the first and last digit of a given number.
assert first_and_last_Digit(123) == [1, 3]
"""

def first_and_last_Digit(num):
    return [int(str(num)[0]), int(str(num)[-1])]

print(first_and_last_Digit(123))

"""
Write a python function to find the sum of digits of a given number.
assert sum_of_digits(123) == 6
"""

def sum_of_digits(num):
    return sum([int(i) for i in str(num)])

print(sum_of_digits(123))

"""
Write a python function to find the sum of digits of a given number.
assert sum_of_digits(123) == 6
"""

def sum_of_digits(num):
    return sum([int(i) for i in str(num)])

print(sum_of_digits(123))

"""
Write a python function to find the sum of digits of a given number.
assert sum_of_digits(123) == 6
"""

def sum_of_digits(num):
    return sum([int(i) for i in str(num)])

print(sum_of_digits(123))

"""
Write a python function to find the sum of digits of a given number.
assert sum_of_digits(123) == 6
"""

def sum_of_digits(num):
    return sum([int(i) for i in str(num)])

print(sum_of_digits(123))

"""
Write a python function to find the sum of digits of a given number.
assert