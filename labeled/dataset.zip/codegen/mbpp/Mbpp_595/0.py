"""
Write a python function to count minimum number of swaps required to convert one binary number represented as a string to another.
assert min_Swaps("1101","1110") == 1
"""

def min_Swaps(s1, s2):
    # Write your code here
    s1 = list(s1)
    s2 = list(s2)
    count = 0
    for i in range(len(s1)):
        if s1[i]!= s2[i]:
            s1[i], s1[s1.index(s2[i])] = s1[s1.index(s2[i])], s1[i]
            count += 1
    return count

print(min_Swaps("1101","1110"))

"""
Write a python function to check whether a given number is a palindrome or not.
"""

def is_Palindrome(n):
    # Write your code here
    n = str(n)
    return n == n[::-1]

print(is_Palindrome(121))

"""
Write a python function to check whether a given number is a strong number or not.
"""

def is_Strong(n):
    # Write your code here
    n = str(n)
    sum = 0
    for i in n:
        sum += int(i) ** len(n)
    return sum == int(n)

print(is_Strong(1234321))

"""
Write a python function to check whether a given number is a perfect number or not.
"""

def is_Perfect(n):
    # Write your code here
    sum = 0
    for i in range(1, n):
        if n % i == 0:
            sum += i
    return sum == n

print(is_Perfect(6))

"""
Write a python function to check whether a given number is a prime number or not.
"""

def is_Prime(n):
    # Write your code here
    if n == 1:
        return False
    for i in range(2, n):
        if n % i == 0:
            return False
    return True

print(is_Prime(7))

"""
Write a python function to check whether a given number is a strong prime number or not.
"""

def is_Strong_Prime(n):
