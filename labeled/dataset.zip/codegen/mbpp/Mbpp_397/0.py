"""
Write a function to find the median of three numbers.
assert median_numbers(25,55,65)==55.0
"""

def median_numbers(a,b,c):
    if a<b:
        if b<c:
            return b
        elif a<c:
            return a
        else:
            return c
    elif a>b:
        if a<c:
            return a
        elif b<c:
            return b
        else:
            return c
    else:
        return a

assert median_numbers(25,55,65)==55.0
assert median_numbers(25,55,65)==55.0
assert median_numbers(25,55,65)==55.0
assert median_numbers(25,55,65)==55.0
assert median_numbers(25,55,65)==55.0
assert median_numbers(25,55,65)==55.0
assert median_numbers(25,55,65)==55.0
assert median_numbers(25,55,65)==55.0
assert median_numbers(25,55,65)==55.0
assert median_numbers(25,55,65)==55.0
assert median_numbers(25,55,65)==55.0
assert median_numbers(25,55,65)==55.0
assert median_numbers(25,55,65)==55.0
assert median_numbers(25,55,65)==55.0
assert median_numbers(25,55,65)==55.0
assert median_numbers(25,55,65)==55.0
assert median_numbers(25,55,65)==55.0
assert median_numbers(25,55,65)==55.0
assert median_numbers(25,55,65)==55.0
assert median_numbers(25,55,65)==55.0
assert median_numbers(25,55,65)==55.0
assert median_numbers(25,55,65)==55.0
assert median_numbers(25,55,65)==55.0
assert median_numbers(25,55,65)==55.0
assert median_n