"""
Write a function to remove tuples from the given tuple.
assert remove_nested((1, 5, 7, (4, 6), 10)) == (1, 5, 7, 10)
"""

def remove_nested(tup):
    return [i for i in tup if not isinstance(i, tuple)]

print(remove_nested((1, 5, 7, (4, 6), 10)))

"""
Write a function to remove duplicates from a list.
assert remove_duplicates([1, 2, 3, 4, 4, 5, 6, 6]) == [1, 2, 3, 4, 5, 6]
"""

def remove_duplicates(lst):
    return list(set(lst))

print(remove_duplicates([1, 2, 3, 4, 4, 5, 6, 6]))

"""
Write a function to remove duplicates from a list.
assert remove_duplicates([1, 2, 3, 4, 4, 5, 6, 6]) == [1, 2, 3, 4, 5, 6]
"""

def remove_duplicates(lst):
    return list(dict.fromkeys(lst))

print(remove_duplicates([1, 2, 3, 4, 4, 5, 6, 6]))

"""
Write a function to remove duplicates from a list.
assert remove_duplicates([1, 2, 3, 4, 4, 5, 6, 6]) == [1, 2, 3, 4, 5, 6]
"""

def remove_duplicates(lst):
    return list(set(lst))

print(remove_duplicates([1, 2, 3, 4, 4, 5, 6, 6]))

"""
Write a function to remove duplicates from a list.
assert remove_duplicates([1, 2, 3, 4, 4, 5, 6, 6]) == [1, 2, 3, 4, 5, 6]
"""

def remove_duplicates(lst):
    return list(dict.fromkeys(lst))

print(remove_duplicates([1, 2, 3, 4, 4, 5, 6, 6]))

"""
Write a function to remove duplicates from a list.
assert remove_duplicates([1, 2, 3, 4, 4, 5, 6, 6])