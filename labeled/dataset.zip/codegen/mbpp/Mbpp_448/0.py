"""
Write a function to calculate the sum of perrin numbers.
assert cal_sum(9) == 49
"""

def cal_sum(n):
    """
    :param n: int
    :return: int
    """
    if n == 1:
        return 1
    elif n == 2:
        return 2
    else:
        return cal_sum(n-1) + cal_sum(n-2)

def cal_sum_iter(n):
    """
    :param n: int
    :return: int
    """
    if n == 1:
        return 1
    elif n == 2:
        return 2
    else:
        a, b = 1, 2
        for i in range(3, n+1):
            a, b = b, a+b
        return b

def cal_sum_iter_2(n):
    """
    :param n: int
    :return: int
    """
    if n == 1:
        return 1
    elif n == 2:
        return 2
    else:
        a, b = 1, 2
        for i in range(3, n+1):
            a, b = b, a+b
        return b

def cal_sum_iter_3(n):
    """
    :param n: int
    :return: int
    """
    if n == 1:
        return 1
    elif n == 2:
        return 2
    else:
        a, b = 1, 2
        for i in range(3, n+1):
            a, b = b, a+b
        return b

def cal_sum_iter_4(n):
    """
    :param n: int
    :return: int
    """
    if n == 1:
        return 1
    elif n == 2:
        return 2
    else:
        a, b = 1, 2
        for i in range(3, n+1):
            a, b = b, a+b
        return b

def cal_sum_iter_5(n):
    """
    :param n: int
    :return: int
    """
    if n == 1:
        return 1
    elif n == 2:
        return 2
