"""
Write a function to convert more than one list to nested dictionary.
assert convert_list_dictionary(["S001", "S002", "S003", "S004"],["Adina Park", "Leyton Marsh", "Duncan Boyle", "Saim Richards"] ,[85, 98, 89, 92])==[{'S001': {'Adina Park': 85}}, {'S002': {'Leyton Marsh': 98}}, {'S003': {'Duncan Boyle': 89}}, {'S004': {'Saim Richards': 92}}]
"""

def convert_list_dictionary(keys, values, grades):
    """
    :param keys: list of student ids
    :param values: list of student names
    :param grades: list of student grades
    :return: list of dictionaries
    """
    return [{keys[i]: {values[i]: grades[i]}} for i in range(len(keys))]

assert convert_list_dictionary(["S001", "S002", "S003", "S004"],["Adina Park", "Leyton Marsh", "Duncan Boyle", "Saim Richards"],[85, 98, 89, 92])==[{'S001': {'Adina Park': 85}}, {'S002': {'Leyton Marsh': 98}}, {'S003': {'Duncan Boyle': 89}}, {'S004': {'Saim Richards': 92}}]

"""
Write a function to convert a list of dictionaries to a dictionary of lists.
assert convert_list_dictionary_to_dictionary_of_lists([{'S001': {'Adina Park': 85}}, {'S002': {'Leyton Marsh': 98}}, {'S003': {'Duncan Boyle': 89}}, {'S004': {'Saim Richards': 92}}])=={'S001': [85], 'S002': [98], 'S003': [89], 'S004': [92]}
"""

def convert_list_dictionary_to_dictionary_of_lists(dictionaries):
    """
    :param dictionaries: list of dictionaries
    :return: dictionary of lists
    """
    return {key: [value[key] for value in dictionaries] for key in dictionaries[0]}

assert convert_list_dictionary_to_dictionary_of_lists([{'S001': {'Adina Park': 85}}, {'S002': {'Leyton Marsh': 98}}, {'S003': {'Duncan Boyle': 89}}, {'S004': {'Saim Richards': 92}}])=={'S001': [85], 'S002': [98], 'S003': [89], 'S004': [92]}