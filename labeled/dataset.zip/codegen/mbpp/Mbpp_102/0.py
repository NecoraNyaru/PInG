"""
Write a function to convert a snake case string to camel case string.
assert snake_to_camel('python_program')=='PythonProgram'
"""

def snake_to_camel(s):
    """
    :type s: str
    :rtype: str
    """
    if not s:
        return s
    if len(s) == 1:
        return s[0].upper()
    return s[0].lower() + s[1:].title()

assert snake_to_camel('python_program')=='PythonProgram'
assert snake_to_camel('python_program_')=='PythonProgram'
assert snake_to_camel('python_program_1')=='PythonProgram1'
assert snake_to_camel('python_program_1_')=='PythonProgram1'
assert snake_to_camel('python_program_1_2')=='PythonProgram12'
assert snake_to_camel('python_program_1_2_')=='PythonProgram12'
assert snake_to_camel('python_program_1_2_3')=='PythonProgram123'
assert snake_to_camel('python_program_1_2_3_')=='PythonProgram123'
assert snake_to_camel('python_program_1_2_3_4')=='PythonProgram1234'
assert snake_to_camel('python_program_1_2_3_4_')=='PythonProgram1234'
assert snake_to_camel('python_program_1_2_3_4_5')=='PythonProgram12345'
assert snake_to_camel('python_program_1_2_3_4_5_')=='PythonProgram12345'
assert snake_to_camel('python_program_1_2_3_4_5_6')=='PythonProgram123456'
assert snake_to_camel('python_program_1_2_3_4_5_6_')=='PythonProgram123456'
assert snake_to_camel('python_program_1_2_3_4_5_6_7')=='PythonProgram1234567'
assert snake_to_camel('python