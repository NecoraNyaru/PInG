"""
Write a function to remove leading zeroes from an ip address.
assert removezero_ip("216.08.094.196")==('216.8.94.196')
"""

def removezero_ip(ip):
    ip_list = ip.split('.')
    for i in range(len(ip_list)):
        if ip_list[i] == '0':
            ip_list[i] = ''
        else:
            break
    return '.'.join(ip_list)

assert removezero_ip("216.08.094.196")==('216.8.94.196')
assert removezero_ip("010.0.0.010")==('10.0.0.010')
assert removezero_ip("010.0.0.0")==('10.0.0.0')
assert removezero_ip("010.0.0.1")==('10.0.0.1')
assert removezero_ip("010.0.0.0.1")==('10.0.0.0.1')
assert removezero_ip("010.0.0.0.0.1")==('10.0.0.0.0.1')
assert removezero_ip("010.0.0.0.0.0.1")==('10.0.0.0.0.0.1')
assert removezero_ip("010.0.0.0.0.0.0.1")==('10.0.0.0.0.0.0.1')
assert removezero_ip("010.0.0.0.0.0.0.0.1")==('10.0.0.0.0.0.0.0.1')
assert removezero_ip("010.0.0.0.0.0.0.0.0.1")==('10.0.0.0.0.0.0.0.0.1')
assert removezero_ip("010.0.0.0.0.0.0.0.0.0.1")==('10.0.0.0.0.0.0.0.0.0.1')
assert removezero_ip("010.0.0.0.0.0.0.0.0.0.0.1")==('10.0.0.0.0.0.0