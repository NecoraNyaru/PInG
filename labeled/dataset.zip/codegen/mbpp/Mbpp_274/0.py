"""
Write a python function that takes in a positive integer n and finds the sum of even index binomial coefficients.
assert even_binomial_Coeff_Sum(4) == 8
"""

def even_binomial_Coeff_Sum(n):
    """
    :param n: positive integer
    :return: sum of even index binomial coefficients
    """
    if n == 0:
        return 0
    elif n == 1:
        return 1
    else:
        return (n * even_binomial_Coeff_Sum(n - 1)) + even_binomial_Coeff_Sum(n - 2)

assert even_binomial_Coeff_Sum(4) == 8
assert even_binomial_Coeff_Sum(5) == 10
assert even_binomial_Coeff_Sum(6) == 12
assert even_binomial_Coeff_Sum(7) == 14
assert even_binomial_Coeff_Sum(8) == 16
assert even_binomial_Coeff_Sum(9) == 18
assert even_binomial_Coeff_Sum(10) == 20
assert even_binomial_Coeff_Sum(11) == 22
assert even_binomial_Coeff_Sum(12) == 24
assert even_binomial_Coeff_Sum(13) == 26
assert even_binomial_Coeff_Sum(14) == 28
assert even_binomial_Coeff_Sum(15) == 30
assert even_binomial_Coeff_Sum(16) == 32
assert even_binomial_Coeff_Sum(17) == 34
assert even_binomial_Coeff_Sum(18) == 36
assert even_binomial_Coeff_Sum(19) == 38
assert even_binomial_Coeff_Sum(20) == 40
assert even_binomial_Coeff_Sum(21) == 42
assert even_binomial_Coeff_Sum(22) == 44
assert even_binomial_Coeff_Sum(23) == 46
assert even_binomial_Coeff_Sum(24) == 48
assert even_binomial_Coeff_Sum(25) == 50
assert even_binomial_Coeff_Sum(26) == 52
assert even_binomial_Coeff_Sum(27)