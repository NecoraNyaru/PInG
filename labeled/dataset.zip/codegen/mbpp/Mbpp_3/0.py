"""
Write a python function to identify non-prime numbers.
assert is_not_prime(2) == False
"""

def is_not_prime(n):
    if n == 1:
        return False
    if n == 2:
        return True
    if n % 2 == 0:
        return False
    for i in range(3, int(n**0.5)+1, 2):
        if n % i == 0:
            return False
    return True

assert is_not_prime(2) == False
assert is_not_prime(3) == True
assert is_not_prime(4) == False
assert is_not_prime(5) == True
assert is_not_prime(6) == False
assert is_not_prime(7) == True
assert is_not_prime(8) == False
assert is_not_prime(9) == True
assert is_not_prime(10) == False
assert is_not_prime(11) == True
assert is_not_prime(12) == False
assert is_not_prime(13) == True
assert is_not_prime(14) == False
assert is_not_prime(15) == True
assert is_not_prime(16) == False
assert is_not_prime(17) == True
assert is_not_prime(18) == False
assert is_not_prime(19) == True
assert is_not_prime(20) == False
assert is_not_prime(21) == True
assert is_not_prime(22) == False
assert is_not_prime(23) == True
assert is_not_prime(24) == False
assert is_not_prime(25) == True
assert is_not_prime(26) == False
assert is_not_prime(27) == True
assert is_not_prime(28) == False
assert is_not_prime(29) == True
assert is_not_prime(30) == False
assert is_not_prime(31) == True
assert is_not_prime(32) == False
assert is_not_prime(33) == True
assert is_not_prime(34) == False
assert is_not_prime(35) == True
assert is_not_prime(36) == False
assert is_not_prime(